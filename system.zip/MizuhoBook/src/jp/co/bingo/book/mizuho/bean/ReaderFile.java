package jp.co.bingo.book.mizuho.bean;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ReaderFile {

	private FileInputStream fileInputStream = null;
	private InputStreamReader inputStreamReader = null;
	private BufferedReader bufferedReader = null;

	public ReaderFile(String filePath) throws IOException {
		fileInputStream = new FileInputStream(filePath);
		inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
		this.bufferedReader = new BufferedReader(inputStreamReader);
	}

	public List<String> readFile() throws IOException {
		List<String> lineString = new ArrayList<>();
		String line = null;
		while ((line = this.bufferedReader.readLine()) != null) {
			lineString.add(line);
		}
		return lineString;
	}

	public void close() throws IOException {
		this.fileInputStream.close();
		this.bufferedReader.close();
	}
}
