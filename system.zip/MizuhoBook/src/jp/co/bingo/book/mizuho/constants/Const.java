package jp.co.bingo.book.mizuho.constants;

public class Const {

	public static final String EMPLOYEE_FILE_PATH = "C:\\Users\\MIZUHO\\Desktop\\employee.txt";

}
