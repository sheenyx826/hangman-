package jp.co.bingo.book.mizuho.bean;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriterFile {

	private FileWriter frd;
	private BufferedWriter bufferedWriter;

	public WriterFile(String filepath, boolean append) throws IOException {
		this.frd = new FileWriter(filepath, append);
		this.bufferedWriter = new BufferedWriter(this.frd);

	}

	public WriterFile(String filepath) throws IOException {
		this(filepath, true);
	}

	public void write(String line) throws IOException {
		this.bufferedWriter.write(line);
	}

	public void close() throws IOException {
		this.bufferedWriter.close();
		this.frd.close();
	}

}