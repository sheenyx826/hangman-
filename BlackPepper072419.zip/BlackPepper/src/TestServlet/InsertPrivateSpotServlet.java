package TestServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PrivateSpot;
import dao.PrivateSpotDAO;
import ds.ConnectionManager;

/**
 * 個人スポット情報登録用サーブレット
 */
@WebServlet("/InsertPrivateSpotServlet")
public class InsertPrivateSpotServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// String url = ConstURL.InsertDoneMembers_PATH;
		// String errorURL = ConstURL.InsertInputMembers_PATH;
		String errorMessage = "入力した個人スポットIDはすでに使用されています。";
		String Id = request.getParameter("txtId");
		String Name = request.getParameter("txtName");
		String MemberId = request.getParameter("txtMemberId");

		try (Connection con = ConnectionManager.getConnection()) {

			try {
				PrivateSpotDAO dao = new PrivateSpotDAO(con);

				PrivateSpot privateSpot = new PrivateSpot();
				privateSpot.setPrivateSpotId(Id);
				privateSpot.setPrivateSpotName(Name);
				privateSpot.setMemberId(MemberId);
				dao.insert(privateSpot);
				request.setAttribute("privateSpot", privateSpot);

			} finally {

			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
		}

		// request.getRequestDispatcher(url).forward(request, response);
	}
}
