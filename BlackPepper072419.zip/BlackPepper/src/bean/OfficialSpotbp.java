package bean;

import java.io.Serializable;

public class OfficialSpotbp implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String officialSpotId;
	private String officialSpotName;
	private String spotInfId;
	public String getOfficialSpotId() {
		return officialSpotId;
	}
	public void setOfficialSpotId(String officialSpotId) {
		this.officialSpotId = officialSpotId;
	}
	public String getOfficialSpotName() {
		return officialSpotName;
	}
	public void setOfficialSpotName(String officialSpotName) {
		this.officialSpotName = officialSpotName;
	}
	public String getSpotInfId() {
		return spotInfId;
	}
	public void setSpotInfId(String spotInfId) {
		this.spotInfId = spotInfId;
	}
	@Override
	public String toString() {
		return "OfficialSpotbp [officialSpotId=" + officialSpotId + ", officialSpotName=" + officialSpotName
				+ ", spotInfId=" + spotInfId + "]";
	}





}
