package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import bean.Reservation;
import constants.ConstURL;
import dao.ProductDAO;
import dao.ReservationDAO;
import ds.ConnectionManager;

/**
 * 予約キャンセル確認画面表示用サーブレット
 */
@WebServlet("/ConfirmCancelReservationServlet")
public class ConfirmCancelReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		Product product = (Product) session.getAttribute("product");
		String productId = product.getProductId();
		String userId = (String) session.getAttribute("userId_tmp");
		ConnectionManager connectionManager = new ConnectionManager();
		Reservation reservationId = new Reservation();

		try (
				// コネクションを取得
				Connection con = connectionManager.getConnection();) {

			// ReservationDAOのインスタンスを生成
			ReservationDAO reservationDAO = new ReservationDAO(con);

			// reservationDAOから予約詳細情報メソッドを呼び出しreservationに入れる。
			reservationId = reservationDAO.selectReservationHistoryDetail(con, userId, productId);
			System.out.println(reservationId);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}

		request.setAttribute("reservationId", reservationId);

		String url = ConstURL.CONFIRM_CANCEL_RESERVATION_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}

}
