package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Spot;
import constants.ConstURL;
import dao.SpotDAO;
import ds.ConnectionManager;

/**
 * スポット検索・一覧画面（ログイン後）表示用サーブレット
 */
@WebServlet("/SearchAndDisplaySpotServlet")
public class SearchAndDisplaySpotServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String SpotName = request.getParameter("spotName");
		String tmpId = request.getParameter("tmpId");
		String dayNumber = request.getParameter("dayNumber");
		String timeState = request.getParameter("timeState");
		String sequenceInf = request.getParameter("sequenceInf");
		System.out.println(tmpId);
		System.out.println(dayNumber);
		System.out.println(timeState);
		System.out.println(sequenceInf);
		request.setAttribute("addedSpotInf", tmpId);
		request.setAttribute("addedSpotDayNumber", dayNumber);
		request.setAttribute("addedSpotTimeState", timeState);
		request.setAttribute("addedSpotSequenceInf", sequenceInf);
		try (Connection con = ConnectionManager.getConnection()) {
			SpotDAO dao = new SpotDAO(con);
			Spot spot = new Spot();
			List<Spot> spotList = new ArrayList<Spot>();

			spotList = dao.selectByName(SpotName);
			if (SpotName != null) {
				request.setAttribute("spotList", spotList);
				request.setAttribute("SpotInf", tmpId);
				request.setAttribute("addedSpotInf", tmpId);

			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		String url = ConstURL.SEARCH_AND_DISPLAY_SPOT_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}
}
