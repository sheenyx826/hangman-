package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Itinerary;
import bean.SpotInf;
import constants.ConstURL;
import dao.ItineraryDAO;
import dao.SpotDAO;
import dao.SpotInfDAO;
import ds.ConnectionManager;

/**
 * フリーツアー作成・日程ランキング一覧画面表示用サーブレット
 */
@WebServlet("/CreateFreeTourAndDisplayRankingServlet")
public class CreateFreeTourAndDisplayRankingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String countryId = request.getParameter("country");
		if (!(countryId == null || countryId.isEmpty())) {
			int date = Integer.parseInt(request.getParameter("day"));
			String memberId = (String) session.getAttribute("userId_tmp");
			Timestamp date_tmp = new Timestamp(new Date().getTime());
			String ItineraryId = date_tmp + memberId;
			try (Connection con = ConnectionManager.getConnection()) {

				ItineraryDAO itineraryDAO = new ItineraryDAO(con);
				Itinerary itinerary = new Itinerary();
				itinerary.setItineraryId(ItineraryId);
				itinerary.setCountryId(countryId);
				itinerary.setCreateTime(date_tmp);
				itinerary.setMemberId(memberId);
				itineraryDAO.insert(itinerary);

			} catch (SQLException | NamingException e) {
				throw new ServletException(e);
			}

			try (Connection con = ConnectionManager.getConnection()) {
				List<SpotInf> list = new ArrayList<SpotInf>();
				Map<String, SpotInf> map = new HashMap<String, SpotInf>();

				SpotInfDAO spotInfDAO = new SpotInfDAO(con);
				spotInfDAO.createItineraryitem(ItineraryId, date);
				list = spotInfDAO.selectByItineraryId(ItineraryId);
				int i = 1;

				for (SpotInf spotInf : list) {

					map.put(String.valueOf(i), spotInf);

					i++;
				}
				session.setAttribute("map", map);
			} catch (SQLException | NamingException e) {
				throw new ServletException(e);
			}
		}

		// session.removeAttribute("spotInfList");
		//
		List<SpotInf> spotInfList = (List<SpotInf>) session.getAttribute("spotInfList");

		if (spotInfList == null) {
			spotInfList = new ArrayList<SpotInf>();

		}
		String addedSpotId = request.getParameter("addedSpotId");
		String addedSpotName = null;

		if (addedSpotId != null) {
			try (Connection con = ConnectionManager.getConnection()) {

				SpotDAO dao = new SpotDAO(con);

				addedSpotName = dao.DisplaySpotNameById(addedSpotId);

			} catch (SQLException | NamingException e) {
				throw new ServletException(e);
			}

		}

		String addedSpotInf = request.getParameter("tmpId");
		String addedSpotDayNumber = request.getParameter("addedSpotDayNumber");
		String addedSpotTimeState = request.getParameter("addedSpotTimeState");
		String addedSpotSequenceInf = request.getParameter("addedSpotSequenceInf");
		System.out.println(addedSpotId);
		System.out.println("--------addedSpotName-------");
		System.out.println(addedSpotName);
		System.out.println("---------------");
		System.out.println(addedSpotInf);
		System.out.println(addedSpotDayNumber);
		System.out.println(addedSpotTimeState);
		System.out.println(addedSpotSequenceInf);
		if (addedSpotId != null) {
			Map<String, SpotInf> map = new HashMap<String, SpotInf>();
			session.getAttribute("map");
			SpotInf spotInf = new SpotInf();
			spotInf.setDayNumber(addedSpotDayNumber);
			spotInf.setSequenceInf(addedSpotSequenceInf);
			spotInf.setTimeState(addedSpotTimeState);
			spotInf.setSpotId(addedSpotId);
			map.put(addedSpotInf, spotInf);
			Map<String, String> map1 = new HashMap<String, String>();
			String key = "spotName" + addedSpotInf;
			session.setAttribute(key, addedSpotName);

		}
		//
		// String itineraryId=null;
		// itineraryId = request.getParameter("itineraryId");
		//
		// if (!(itineraryId.isEmpty()||itineraryId==null)) {
		// // String dayNumber = request.getParameter("dayNumber");
		// // String timeState = request.getParameter("timestate");
		// // String sequenceInf = request.getParameter("sequenceinf");
		// String tmpId = request.getParameter("tmpId");
		// String spotId = request.getParameter("spotId");
		// String spotInfId = itineraryId + tmpId;
		// SpotInf spotInf = new SpotInf();
		// spotInf.setItineraryId(itineraryId);
		// spotInf.setSpotId(spotId);
		// spotInf.setSpotInfId(spotInfId);
		//
		// spotInfList.add(spotInf);
		// request.setAttribute("spotInf", spotInf);
		// session.setAttribute("spotInfList", spotInfList);
		// }

		String url = ConstURL.CREATE_FREE_TOUR_AND_DISPLAY_RANKING_PATH;

		request.getRequestDispatcher(url).forward(request, response);

	}

}
