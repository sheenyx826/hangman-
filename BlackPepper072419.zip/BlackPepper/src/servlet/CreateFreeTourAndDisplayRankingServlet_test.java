package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.SpotInf;

/**
 * フリーツアー作成・日程ランキング一覧画面表示用サーブレット
 */
@WebServlet("/CreateFreeTourAndDisplayRankingServlet_test")
public class CreateFreeTourAndDisplayRankingServlet_test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		//

		// //
		// int date = 9;
		// String memberId = "5";
		// String ItineraryId = "sss";
		//
		// try (Connection con = ConnectionManager.getConnection()) {
		//
		// SpotInfDAO spotInfDAO = new SpotInfDAO(con);
		// spotInfDAO.createItineraryitem(ItineraryId, date);
		//
		// } catch (SQLException | NamingException e) {
		// throw new ServletException(e);
		// }
		// session.removeAttribute("spotInfList");

		List<SpotInf> spotInfList = (List<SpotInf>) session.getAttribute("spotInfList");

		if (spotInfList == null) {
			spotInfList = new ArrayList<SpotInf>();

		}

		String itineraryId = request.getParameter("itineraryId");
		// String dayNumber = request.getParameter("dayNumber");
		// String timeState = request.getParameter("timestate");
		// String sequenceInf = request.getParameter("sequenceinf");
		String tmpId = request.getParameter("tmpId");
		String spotId = request.getParameter("spotId");
		String spotInfId = itineraryId + tmpId;
		SpotInf spotInf = new SpotInf();
		spotInf.setItineraryId(itineraryId);
		spotInf.setSpotId(spotId);
		spotInf.setSpotInfId(spotInfId);

		spotInfList.add(spotInf);
		request.setAttribute("spotInf", spotInf);
		session.setAttribute("spotInfList", spotInfList);

		String url = "BF503_test.jsp";

		request.getRequestDispatcher(url).forward(request, response);

	}

}
