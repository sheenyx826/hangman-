package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import constants.ConstURL;
import dao.ReservationDAO;
import ds.ConnectionManager;

/**
 * 予約キャンセル完了画面表示用サーブレット
 */
@WebServlet("/CompleteCancelReservationServlet")
public class CompleteCancelReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 予約IDを取得
		String reservationId = request.getParameter("reservationId");
		System.out.println(reservationId);
		ConnectionManager connectionManager = new ConnectionManager();
		try (
				// コネクションを取得
				Connection con = connectionManager.getConnection();) {

			// ReservationDAOのインスタンスを生成
			ReservationDAO reservationDAO = new ReservationDAO(con);

			// ReservationDAOの予約削除メソッドを呼び出す
			reservationDAO.delete(reservationId);

		} catch (NamingException e) {
			throw new ServletException(e);
		} catch (SQLException e) {
			throw new ServletException(e);

		}

		String url = ConstURL.COMPLETE_CANCEL_RESERVATION_PATH;

		request.getRequestDispatcher(url).forward(request, response);

	}

}
