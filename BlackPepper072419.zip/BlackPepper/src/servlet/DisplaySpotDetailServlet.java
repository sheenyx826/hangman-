package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Comment;
import constants.ConstURL;
import dao.CommentDAO;
import ds.ConnectionManager;

/**
 * スポットの詳細画面表示用サーブレット
 */
@WebServlet("/DisplaySpotDetailServlet")
public class DisplaySpotDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.DISPLAY_SPOT_DETAIL_PATH;
		
		List<Comment> commentList = null;
		
		try(Connection con = ConnectionManager.getConnection()){
			CommentDAO newcommentDAO = new CommentDAO(con);
			commentList = newcommentDAO.commentAll(con);
		} catch (SQLException e) {
			throw new ServletException(e);
		} catch (NamingException e) {
			throw new ServletException(e);
		}
		
		
		request.setAttribute("commentList", commentList);
		request.getRequestDispatcher(url).forward(request, response);
	}

}
