package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Itinerary;

/**
 * 旅程表DAO
 *
 * @author yokin
 */

public class ItineraryDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public ItineraryDAO(Connection con) {
		this.con = con;
	}

	public int insert(Itinerary itinerary) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO ITINERARY(ITINERARY_ID, MEMBER_ID, ITINERARY_NAME, CREATE_TIME, ITINERARY_OVERVIEW, COUNTRY_ID, COUNTRY_NAME )"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?)";
		System.out.println("itinerary:" + itinerary);
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, itinerary.getItineraryId());
			ps.setString(2, itinerary.getMemberId());
			ps.setString(3, itinerary.getItineraryName());
			ps.setTimestamp(4, itinerary.getCreateTime());
			ps.setString(5, itinerary.getItineraryOverview());
			ps.setString(6, itinerary.getCountryId());
			ps.setString(7, itinerary.getCountryName());

			cnt = ps.executeUpdate();
			System.out.println("INSERT INTO ITINERARY:" + cnt);
		}
		return cnt;
	}

	// public int delete(String ItineraryId) throws SQLException {
	//
	// int cnt = 0;
	// String sql = "DELETE FROM ITINERARY WHERE ITINERARY_ID = ?";
	//
	// Itinerary itinerary = new Itinerary();
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	//
	// ps.setString(1, itinerary.());
	// cnt = ps.executeUpdate();
	// }

}