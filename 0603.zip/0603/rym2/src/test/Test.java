package test;

import java.io.IOException;

import bean.SalesLogic;

public class Test {

	public static void main(String[] args) {

		try {
			//ProductLogic.deleteAll();
//					ProductLogic.registerProduct();
//			ProductLogic.repairProduct();
//		ProductLogic.displayProductAll();
			//
			//			//SalesLogic.deleteAll();
//					SalesLogic.registerSales();
						//SalesLogic.repairSales();
			SalesLogic.displaySalesAll();
//						SalesLogic.displayTotalPrice();

		} catch (IOException | NullPointerException e) {
			e.printStackTrace();
		}
	}
}
