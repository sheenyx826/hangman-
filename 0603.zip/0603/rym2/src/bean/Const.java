package bean;

public class Const {

	public static final String PRODUCT_FILE_PATH = "/Users/xinye/Desktop/テストファイル/ポケモン(Product)_windows31J.csv";
	public static final String SALES_FILE_PATH = "/Users/xinye/Desktop/テストファイル/売上(sale)_windows31J.csv";
	public static final String EMPLOYEE_FILE_PATH = "/Users/xinye/Desktop/テストファイル/ポケモン(Employee)_windows31J.csv";

}