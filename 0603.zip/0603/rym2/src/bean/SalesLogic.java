package bean;

import java.io.IOException;
import java.util.Scanner;


public class SalesLogic {
	public static void registerSales() throws IOException {
		boolean isYetRegister;
		Scanner scanner;
		do {
			scanner = new Scanner(System.in);
			Sales sales = new Sales();
			System.out.println("売り上げNoを入力してください");
			sales.setSalesNo(Integer.parseInt(scanner.next()));
			System.out.println("商品Noを入力してください");
			sales.setProductNo(Integer.parseInt(scanner.next()));
			System.out.println("数量を入力してください");
			sales.setQuantity(Integer.parseInt(scanner.next()));
			System.out.println("店舗Noを入力してください");
			sales.setStoreNo(Integer.parseInt(scanner.next()));
			sales.insert();
			System.out.println("まだ登録しますか？ y or n");
			isYetRegister = scanner.next().equalsIgnoreCase("y");
		} while (isYetRegister);
		scanner.close();
	}

	public static void displaySalesAll() throws IOException {
		System.out.println("売り上げの一覧を表示します");
		for (Sales p : new Sales().selectAll()) {
			System.out.println(p);
		}
	}

	public static void displayTotalPrice() throws IOException {
		System.out.println("売上総合計金額を表示します");
		int totalPrice = 0;
		for (Sales p : new Sales().selectAll()) {
			totalPrice += p.calcSubTotal();
		}
		System.out.println("全売上の総合計" + totalPrice + "円");
	}

	public static void deleteAll() throws IOException {
		new Sales().delete();
		// TODO 仕様書通り文書を表示する
		System.out.println("売り上げ全部消しちゃったてへぺろーー");
	}

}