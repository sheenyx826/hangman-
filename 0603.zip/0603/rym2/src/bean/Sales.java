package bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Sales {
	private int salesNo;
	private int productNo;
	private int quantity;
	private int storeNo;
	private Product product;

	public Sales() {
	}

	public Sales(String lineString) throws IOException {
		String[] split = lineString.split(",");
		this.salesNo = Integer.parseInt(split[0]);
		this.productNo = Integer.parseInt(split[1]);
		this.quantity = Integer.parseInt(split[2]);
		this.storeNo = Integer.parseInt(split[3]);

		Product product = new Product(productNo);
		this.product = product.selectByMyProductNo();
	}

	public void insert() throws IOException {
		ファイル書き込み部品 writer = new ファイル書き込み部品(Const.SALES_FILE_PATH);
		writer.write(createLineString());
		writer.close();

	}

	public void delete() throws IOException {
		ファイル書き込み部品 writer = new ファイル書き込み部品(Const.SALES_FILE_PATH, false);
		writer.close();
	}

	public List<Sales> selectAll() throws IOException {
		List<Sales> products = new ArrayList<Sales>();
		ファイル読み込み部品 reader = new ファイル読み込み部品(Const.SALES_FILE_PATH);
		List<String> fileString = reader.readFile();
		for (String lineString : fileString) {
			Sales product = new Sales(lineString);
			products.add(product);
		}
		reader.close();
		return products;
	}

	private String createLineString() {
		return this.salesNo + "," + this.productNo + "," + this.quantity + "," + this.storeNo + "¥n";
	}

	public int calcSubTotal() {
		return this.quantity * this.product.getPrice();
	}

	public int getSalesNo() {
		return salesNo;
	}

	public void setSalesNo(int salesNo) {
		this.salesNo = salesNo;
	}

	public int getProductNo() {
		return productNo;
	}

	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(int storeNo) {
		this.storeNo = storeNo;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Sale [salesNo=" + salesNo + ", productNo=" + productNo + ", quantity=" + quantity + ", storeNo="
				+ storeNo + ", product=" + product + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + productNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sales other = (Sales) obj;
		if (productNo != other.productNo)
			return false;
		return true;
	}

	//後は各自でセッターゲッター、toString、equals、hashcode入れてください。
	//ハッシュコード、equalsに関してproductNoのみ選択して行わないと後後でバグ吐くらしいから注意！！！

}
