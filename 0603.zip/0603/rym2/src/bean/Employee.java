package bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Employee {
	private int Id;
	private String Pass;
	private String Name;
	private String Role;
	private String storeNo;
	private String adress;
	
public Employee() {
		
	}

	public Employee(int Id) {
		this.Id = Id;
	}
	
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (Id != other.Id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Pass=" + Pass + ", Name=" + Name + ", Role=" + Role + ", storeNo=" + storeNo
				+ ", adress=" + adress + "]";
	}
	
	

	public Employee(String lineString) {
		String[] split = lineString.split(",");

		this.Id = Integer.parseInt(split[0]);
		this.Pass = split[1];
		this.Name = split[2];
		this.Role = split[3];
		this.storeNo = split[4];
		this.adress = split[5];

	}
	public List<Employee> selectAll() throws IOException {
		List<Employee> employees = new ArrayList<Employee>();
		ファイル読み込み部品 reader = new ファイル読み込み部品(Const.EMPLOYEE_FILE_PATH);
		List<String> filestring = reader.readFile();
		for (String lineString : filestring) {
			Employee employee = new Employee(lineString);
			employees.add(employee);
		}
		return employees;
	}

	public Employee selectByMyEmployeeNo() throws IOException {
		Employee employee = new Employee(this.Id);
		List<Employee> employees = this.selectAll();
		for (Employee e : employees) {
			if (e.equals(employee)) {
				return e;
			}
		}
		return null;

	}

	public String createLineString() {
		return this.Id + "," + this.Pass + "," + this.Name + "," + this.Role + "," + this.storeNo + "," + this.adress + "\n";
	}

}
