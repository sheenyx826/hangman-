package bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Product {

	private int productNo;
	private String productName;
	private int price;

	public Product() {
	}

	public Product(int productNo) {
		this.productNo = productNo;
	}

	public Product(String lineString) {
		String[] split = lineString.split(",");
		//todo
		//		System.out
		//				.println("デバック \n" + "sprit[0]：" + split[0].trim() + "　sprit[1]：" + split[1] + "　sprit[2]："
		//						+ split[2]);
		this.productNo = Integer.parseInt(split[0]);
		this.productName = split[1];
		this.price = Integer.parseInt(split[2]);
	}

	public void insert() throws IOException {
		ファイル書き込み部品 writer = new ファイル書き込み部品(Const.PRODUCT_FILE_PATH);
		writer.close();
	}

	public void delete() throws IOException {
		ファイル書き込み部品 writer = new ファイル書き込み部品(Const.PRODUCT_FILE_PATH, false);
		writer.close();
	}

	public List<Product> selectAll() throws IOException {
		List<Product> products = new ArrayList<Product>();
		ファイル読み込み部品 reader = new ファイル読み込み部品(Const.PRODUCT_FILE_PATH);
		List<String> filestring = reader.readFile();
		for (String lineString : filestring) {
			Product product = new Product(lineString);
			products.add(product);
		}
		return products;
	}

	public Product selectByMyProductNo() throws IOException {
		Product product = new Product(this.productNo);
		List<Product> products = this.selectAll();
		for (Product p : products) {
			if (p.equals(product)) {
				return p;
			}
		}
		return null;

	}

	public String createLineString() {
		return this.productNo + "," + this.productName + "," + this.price + "\n";
	}

	/* (非 Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [productNo=" + productNo + ", productName=" + productName + ", price=" + price + "]";
	}

	/* (非 Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + productNo;
		return result;
	}

	/* (非 Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (productNo != other.productNo)
			return false;
		return true;
	}

	/**
	 * @return productNo
	 */
	public int getProductNo() {
		return productNo;
	}

	/**
	 * @param productNo セットする productNo
	 */
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}

	/**
	 * @return productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName セットする productName
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * @param price セットする price
	 */
	public void setPrice(int price) {
		this.price = price;
	}
}
