package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;

/**
 * Servlet implementation class RegistrationConfirmServlet
 */
@WebServlet("/BackEmployeeListView")
public class BackEmployeeListView extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		
		
		// Actorオブジェクトを生成
		Employee data = new Employee();
		try {
			Employee Adddata = new Employee();
			Adddata.setId(Integer.parseInt(request.getParameter("Id")));
			Adddata.setPass(request.getParameter("Pass"));
			Adddata.setName(request.getParameter("Name"));
			Adddata.setRole(request.getParameter("Role"));
			Adddata.setStoreNo(request.getParameter("storeNo"));
			Adddata.setAdress(request.getParameter("adress"));


		} catch (NumberFormatException e) {
			// TODO: handle exception
		}
		
	// セッションオブジェクトを取得
		HttpSession session = request.getSession();

		// セッションオブジェクトにActorオブジェクトをセット
		session.setAttribute("user", data.selectAll());
//
//		// confirmActor.jspにフォワード
		
		request.getRequestDispatcher("WEB-INF/outputEmployee.jsp").forward(request, response);
	}

}
