package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;

/**
 * Servlet implementation class RegistrationConfirmServlet
 */
@WebServlet("/BackProductListView")
public class BackProductListView extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		
		
		// Actorオブジェクトを生成
		Product data = new Product();
		try {
			Product Adddata = new Product();
			Adddata.setProductNo(Integer.parseInt(request.getParameter("id")));
			Adddata.setProductName(request.getParameter("name"));
			Adddata.setPrice(Integer.parseInt(request.getParameter("price")));
			Adddata.insert();
		} catch (NumberFormatException e) {
			// TODO: handle exception
		}
		
	// セッションオブジェクトを取得
		HttpSession session = request.getSession();

		// セッションオブジェクトにActorオブジェクトをセット
		session.setAttribute("user", data.selectAll());
//
//		// confirmActor.jspにフォワード
		
		request.getRequestDispatcher("WEB-INF/output.jsp").forward(request, response);
	}

}
