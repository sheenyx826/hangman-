package dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Comment;

/**
 * コメントDAO
 * 
 * @author katakura
 */
public class CommentDAO {
	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */

	public CommentDAO(Connection con) {
		this.con = con;
	}

	/**
	 * コメント登録
	 */

	public int insert(Connection con, Comment comment) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO COMMENT_INF(COMMENT_ID,COMMENT_CONTENT,COMMENT_TIME,MEMBER_ID,SPOT_ID,GRADE,ITINERARY_ID,PRODUCT_ID)　VALUES(?,?,?,?,?,?,?,?)";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, comment.getCommentId());
			ps.setString(2, comment.getCommentContent());
			ps.setTimestamp(3, comment.getCommentTime());
			ps.setString(4, comment.getMemberId());
			ps.setString(5, comment.getSpotId());
			ps.setInt(6, comment.getGrade());
			ps.setString(7, comment.getItineraryId());
			ps.setString(8, comment.getProductId());
			cnt = ps.executeUpdate();
		}

		return cnt;
	}

	/**
	 * コメント表示メソッド
	 */

	public List<Comment> commentAll(String spotId) throws SQLException {
		String sql = "SELECT ci.COMMENT_ID,ci.COMMENT_CONTENT,ci.COMMENT_TIME,ci.MEMBER_ID,ci.SPOT_ID,ci.GRADE,ci.ITINERARY_ID,ci.PRODUCT_ID,ci.MEMBER_ID,m.member_name FROM COMMENT_INF ci JOIN MEMBERS m ON ci.member_id = m.member_id  WHERE SPOT_ID = ? ORDER BY COMMENT_ID";
		List<Comment> commentList = new ArrayList<Comment>();

		try (PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setString(1, spotId);
			System.out.println("comment:" + spotId);
			try (ResultSet rs = ps.executeQuery();) {

				while (rs.next()) {
					Comment comment = new Comment();
					comment.setCommentId(rs.getString("COMMENT_ID"));
					comment.setCommentContent(rs.getString("COMMENT_CONTENT"));
					comment.setCommentTime(rs.getTimestamp("COMMENT_TIME"));
					comment.setMemberId(rs.getString("MEMBER_ID"));
					comment.setSpotId(rs.getString("SPOT_ID"));
					comment.setGrade(rs.getInt("GRADE"));
					comment.setItineraryId(rs.getString("ITINERARY_ID"));
					comment.setProductId(rs.getString("PRODUCT_ID"));
					comment.setMemberName(rs.getString("MEMBER_NAME"));
					commentList.add(comment);
				}
			}
			return commentList;
		}
	}

	public BigDecimal commentAvg(String spotId) throws SQLException {
		String sql = "SELECT avg(GRADE) FROM COMMENT_INF WHERE SPOT_ID = ?";
		BigDecimal resultAvg = new BigDecimal(0);
		try (PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setString(1, spotId);
			try (ResultSet rs = ps.executeQuery();) {

				if (rs.next()) {
					resultAvg = rs.getBigDecimal("avg(GRADE)");
				}
			}
			return resultAvg;
		}
	}

	public int commentCount(String spotId) throws SQLException {
		String sql = "SELECT count(GRADE) FROM COMMENT_INF WHERE SPOT_ID = ?";
		int resultCount = 0;
		try (PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setString(1, spotId);
			try (ResultSet rs = ps.executeQuery();) {

				if (rs.next()) {
					resultCount = rs.getInt("count(GRADE)");
				}
			}
			return resultCount;
		}
	}
}
