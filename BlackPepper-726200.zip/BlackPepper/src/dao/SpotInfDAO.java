package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.SpotInf;

/**
 * 旅程表項目DAO
 *
 * @author yokin
 */

public class SpotInfDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */
	public SpotInfDAO(Connection con) {
		this.con = con;
	}

	//

	public int createItineraryitem(String id, int date) throws SQLException {
		int cnt = 0;
		int number = 1;
		String sql = "INSERT INTO SPOTINF(SPOT_INFID, ITINERARY_ID, DAYNUMBER, TIMESTATE, SEQUENCEINF)"
				+ "VALUES(?, ?, ?, ?, ?)";
		System.out.println("createItineraryitem date:" + date);
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			for (int i = 1; i <= date; i++) {
				for (int j = 1; j <= 3; j++) {
					for (int h = 1; h <= 3; h++) {
						ps.setString(1, id + String.valueOf(number));
						ps.setString(2, id);
						ps.setString(3, String.valueOf(i));
						ps.setString(4, String.valueOf(j));
						ps.setString(5, String.valueOf(h));
						number++;
						cnt = ps.executeUpdate();
						System.out.println("\"INSERT INTO SPOTINF( cnt:" + cnt);
					}
				}
			}

		}
		return cnt;
	}

	public List<SpotInf> selectByItineraryId(String id) throws SQLException {
		String sql = "SELECT * FROM SPOTINF WHERE ITINERARY_ID=? ORDER BY SPOT_INFID";
		List<SpotInf> list = new ArrayList<SpotInf>();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {
					SpotInf spotInf = new SpotInf();
					spotInf.setDayNumber(rs.getString("DAYNUMBER"));
					spotInf.setItineraryId(rs.getString("ITINERARY_ID"));
					spotInf.setSequenceInf(rs.getString("SEQUENCEINF"));
					spotInf.setSpotId(rs.getString("SPOT_ID"));
					spotInf.setSpotInfId(rs.getString("SPOT_INFID"));
					spotInf.setTimeState(rs.getString("TIMESTATE"));
					spotInf.setTourContent(rs.getString("TOUR_CONTENT"));
					spotInf.setTourName(rs.getString("TOUR_NAME"));
					spotInf.setTourPrice(rs.getString("TOUR_PRICE"));

					list.add(spotInf);
				}
			}
		}
		return list;
	}

	// itineraryIdをもとに金額入りの項目だけ返す
	public List<SpotInf> selectByItineraryIdReturnPrice(String id) throws SQLException {
		String sql = "SELECT * \r\n" + "FROM SPOTINF\r\n" + "WHERE ITINERARY_ID=? AND TOUR_PRICE IS NOT NULL\r\n"
				+ "ORDER BY DAYNUMBER";
		List<SpotInf> list = new ArrayList<SpotInf>();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);

			try (ResultSet rs = ps.executeQuery()) {

				System.out.println("selectByItineraryIdReturnPriceのwehileのid：" + id);
				System.out.println("selectByItineraryIdReturnPriceのwehileはいるよ");
				while (rs.next()) {
					System.out.println("selectByItineraryIdReturnPriceのwehileはいった！！！！！！");
					SpotInf spotInf = new SpotInf();
					spotInf.setDayNumber(rs.getString("DAYNUMBER"));
					spotInf.setItineraryId(rs.getString("ITINERARY_ID"));
					spotInf.setSequenceInf(rs.getString("SEQUENCEINF"));
					spotInf.setSpotId(rs.getString("SPOT_ID"));
					spotInf.setSpotInfId(rs.getString("SPOT_INFID"));
					spotInf.setTimeState(rs.getString("TIMESTATE"));
					spotInf.setTourContent(rs.getString("TOUR_CONTENT"));
					spotInf.setTourName(rs.getString("TOUR_NAME"));
					spotInf.setTourPrice(rs.getString("TOUR_PRICE"));

					list.add(spotInf);
				}
			}
		}
		return list;
	}

	// public int insert(SpotInf spotInf) throws SQLException {
	// int cnt = 0;
	// String sql = "INSERT INTO SPOTINF(EMPLOYEE_ID, EMPLOYEE_NAME, EMPLOYEE_AGE)"
	// + "VALUES(?, ?, ?)";
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	// ps.setString(1, employee.getId());
	// ps.setString(2, employee.getName());
	// ps.setInt(3, employee.getAge());
	// cnt = ps.executeUpdate();
	// }
	// return cnt;
	// }

	/**
	 * 旅程表情報単一取得
	 * 
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	// public SpotInf selectAll() throws SQLException {
	// SpotInf spotInf = null;
	// String sql = "SELECT *FROM SPOTINF WHERE SPOT_INFID =?";
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	// ps.setString(1, id);
	// try (ResultSet rs = ps.executeQuery()) {
	// if (rs.next()) {
	// spotInf = new SpotInf();
	// spotInf.setSpotInfId(rs.getString("SPOT_INFID"));
	// spotInf.setDayNumber(rs.getString("DAYNUMBER"));
	// spotInf.setItineraryId(rs.getString("ITINERARY_ID"));
	// spotInf.setTimeState(rs.getString("TIMESTATE"));
	// spotInf.setSequenceInf(rs.getString("SEQUENCEINF"));
	// spotInf.setSpotId(rs.getString("SPOT_ID"));
	// spotInf.setTourContent(rs.getString("TOUR_CONTENT"));
	// spotInf.setTourName(rs.getString("TOUR_NAME"));
	// spotInf.setTourPrice(rs.getString("TOUR_PRICE"));
	// }
	// }
	// }
	// return spotInf;
	// }

	/**
	 * 旅程表情報変更
	 * 
	 * @param spotInf
	 * @return
	 * @throws SQLException
	 */
	public int update(SpotInf spotInf) throws SQLException {

		int cnt = 0;
		String sql = "UPDATE SPOTINF SET SPOT_ID = ?, TOUR_CONTENT = ?, TOUR_NAME = ?, TOUR_PRICE = ? WHERE SPOT_INFID = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, spotInf.getSpotId());
			ps.setString(2, spotInf.getTourContent());
			ps.setString(3, spotInf.getTourName());
			if (spotInf.getTourPrice() != null) {
				ps.setInt(4, Integer.parseInt(spotInf.getTourPrice()));

			} else {
				ps.setString(4, spotInf.getTourPrice());

			}

			ps.setString(5, spotInf.getSpotInfId());
			cnt = ps.executeUpdate();
		}
		return cnt;

	}

	// public List<SpotInf> updateList(List<SpotInf> list) throws SQLException {
	//
	// List<SpotInf> spotInfList = new ArrayList<SpotInf>();
	// String sql = "UPDATE SPOTINF SET SPOT_ID = ?, TOUR_CONTENT = ?, TOUR_NAME =
	// ?, TOUR_PRICE = ? WHERE SPOT_INFID = ?";
	// try(
	// PreparedStatement ps = con.prepareStatement(sql);
	// ResultSet rs = ps.executeQuery()) {
	// while (rs.next()) {
	// SpotInf spotInf = new SpotInf();
	// ps.setString(1, spotInf.getSpotId());
	// ps.setString(2, spotInf.getTourContent());
	// ps.setString(3, spotInf.getTourName());
	// ps.setString(4, spotInf.getTourPrice());
	// ps.setString(5, spotInf.getSpotInfId());
	//
	// ps.executeUpdate();
	// }
	// return list;
	//
	// }

}