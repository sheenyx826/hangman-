package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Favorite;
import bean.Itinerary;
import bean.Member;
import bean.Reservation;
import bean.Spot;
import constants.ConstURL;
import dao.FavoriteDAO;
import dao.ItineraryDAO;
import dao.MembersDAO;
import dao.ReservationDAO;
import dao.SpotDAO;
import ds.ConnectionManager;

/**
 * マイページ画面表示用サーブレット
 */
@WebServlet("/DisplayMyPageServlet")
public class DisplayMyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		String addedSpotName = request.getParameter("addedSpotName");

		Timestamp date = new Timestamp(new Date().getTime());

		if (!(addedSpotName == null || addedSpotName.isEmpty())) {
			try (Connection con = ConnectionManager.getConnection()) {
				String userId = (String) session.getAttribute("userId_tmp");
				String spotId = date + userId;
				SpotDAO daoSpot = new SpotDAO(con);
				Spot spot = new Spot();
				spot.setSpotId(spotId);
				spot.setMemberId(userId);
				spot.setSpotName(addedSpotName);
				daoSpot.insert(spot);

			} catch (SQLException | NamingException e) {
				throw new ServletException(e);

			}
		}

		try (Connection con = ConnectionManager.getConnection()) {
			MembersDAO dao = new MembersDAO(con);
			Member member = new Member();
			SpotDAO daoSpot = new SpotDAO(con);
			List<Spot> addedSpotList = new ArrayList<Spot>();

			String userId = (String) session.getAttribute("userId_tmp");

			member = dao.selectByMemberId(userId);
			addedSpotList = daoSpot.selectByMemberId(userId);

			session.setAttribute("addedSpotList", addedSpotList);
			session.setAttribute("member", member);
			System.out.println(member);
			// お気に入りリストにお気に入りプロジェクトを追加
			ArrayList<Favorite> favoriteProjectList = new ArrayList<Favorite>();

			FavoriteDAO favoriteDAO = new FavoriteDAO(con);

			favoriteProjectList = favoriteDAO.selectAll(userId);

			session.setAttribute("favoriteProductList", favoriteProjectList);

			// お気に入りリストにお気に入りスポットを追加
			ArrayList<Favorite> favoriteSpotList = new ArrayList<Favorite>();

			favoriteSpotList = favoriteDAO.selectSpotAll(userId);

			session.setAttribute("favoriteSpotList", favoriteSpotList);

			// お気に入りリストにお気に入りフリーツアーを追加
			ArrayList<Favorite> favoriteFreeTourList = new ArrayList<Favorite>();

			favoriteFreeTourList = favoriteDAO.selectFreeTourAll(userId);

			session.setAttribute("favoriteFreeTourList", favoriteFreeTourList);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}
		try (Connection con = ConnectionManager.getConnection()) {
			List<Itinerary> itineraryList = new ArrayList<Itinerary>();

			String userId = (String) session.getAttribute("userId_tmp");

			ItineraryDAO dao = new ItineraryDAO(con);
			itineraryList = dao.selectByMemberId(userId);
			session.setAttribute("itineraryList", itineraryList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		try (Connection con = ConnectionManager.getConnection()) {
			List<Itinerary> itineraryList = new ArrayList<Itinerary>();

			String userId = (String) session.getAttribute("userId_tmp");

			ItineraryDAO dao = new ItineraryDAO(con);
			itineraryList = dao.selectByMemberId(userId);
			request.setAttribute("itineraryList", itineraryList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		// 予約したフリーツアー（旅程表）を表示 ＠叶
		try (Connection con = ConnectionManager.getConnection()) {
			List<Reservation> reservationList = new ArrayList<Reservation>();
			List<Itinerary> itineraryList = new ArrayList<Itinerary>();

			String userId = (String) session.getAttribute("userId_tmp");

			ReservationDAO dao = new ReservationDAO(con);
			reservationList = dao.selectReservationItineraryHistory(userId);
			for (Reservation reservation : reservationList) {

				ItineraryDAO itineraryDao = new ItineraryDAO(con);
				itineraryList.add(itineraryDao.selectByItineraryId(reservation.getItineraryId()));
			}

			request.setAttribute("bookItineraryList", itineraryList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		String url = ConstURL.DISPLAY_MY_PAGE_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}

}
