package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Spot;
import constants.ConstURL;

/**
 * スポットの追加画面表示用サーブレット
 */
@WebServlet("/ConfirmSpotServlet")
public class ConfirmSpotServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {



		String spotName=request.getParameter("addedSpotName");

		Spot spot=new Spot();

		spot.setSpotName(spotName);

		request.setAttribute("spot", spot);

		String url = ConstURL.CONFIRM_SPOT_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}

}
