package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import bean.Spot;
import constants.ConstURL;
import dao.CategoryDAO;
import dao.SpotDAO;
import ds.ConnectionManager;

/**
 * スポット検索・一覧画面（ログイン後）表示用サーブレット
 */
@WebServlet("/SearchAndDisplaySpotServlet")
public class SearchAndDisplaySpotServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		Member member = (Member) session.getAttribute("afterloginmember");
		String SpotName = request.getParameter("spotName");
		String tmpId = request.getParameter("tmpId");
		String dayNumber = request.getParameter("dayNumber");
		String timeState = request.getParameter("timeState");
		String sequenceInf = request.getParameter("sequenceInf");
		String userId = (String) session.getAttribute("userId_tmp");
		String[] genreStringList = null;
		String[] genreStringList1 = { "0", "0", "0", "0", "0", "0", "0", "0", "0" };

		genreStringList = request.getParameterValues("inCharge");
		int i = 0;
		if (genreStringList != null) {
			for (String string : genreStringList) {
				genreStringList1[i] = string;
				i++;
			}
		}

		System.out.println(tmpId);
		System.out.println(dayNumber);
		System.out.println(timeState);
		System.out.println(sequenceInf);
		request.setAttribute("addedSpotInf", tmpId);
		request.setAttribute("addedSpotDayNumber", dayNumber);
		request.setAttribute("addedSpotTimeState", timeState);
		request.setAttribute("addedSpotSequenceInf", sequenceInf);
		try (Connection con = ConnectionManager.getConnection()) {
			SpotDAO dao = new SpotDAO(con);
			Spot spot = new Spot();
			List<Spot> spotList = new ArrayList<Spot>();

			if (userId != null) {
				if (genreStringList == null) {
					spotList = dao.selectByName(SpotName, member);
				}

				else {
					spotList = dao.selectByName(SpotName, member, genreStringList1);

				}

			} else {
				Member member1 = new Member();
				member1.setUserPoint(1);
				if (genreStringList == null) {
					spotList = dao.selectByName(SpotName, member1);

				} else {
					spotList = dao.selectByName(SpotName, genreStringList1);
				}

			}
			List<Spot> newList = spotList;

			try (Connection con1 = ConnectionManager.getConnection()) {
				CategoryDAO dao1 = new CategoryDAO(con1);
				for (Spot spot2 : newList) {
					if (spot2.getCategory1Id() != null) {
						spot2.setCategory1Name(dao1.selectByCategoryId(spot2.getCategory1Id()).getCategoryName());
					}
					if (spot2.getCategory2Id() != null) {
						spot2.setCategory2Name(dao1.selectByCategoryId(spot2.getCategory2Id()).getCategoryName());
					}
					if (spot2.getCategory3Id() != null) {
						spot2.setCategory3Name(dao1.selectByCategoryId(spot2.getCategory3Id()).getCategoryName());
					}
					if (spot2.getCategory4Id() != null) {
						spot2.setCategory4Name(dao1.selectByCategoryId(spot2.getCategory4Id()).getCategoryName());
					}
					if (spot2.getCategory5Id() != null) {
						spot2.setCategory5Name(dao1.selectByCategoryId(spot2.getCategory5Id()).getCategoryName());
					}
					if (spot2.getCategory6Id() != null) {
						spot2.setCategory6Name(dao1.selectByCategoryId(spot2.getCategory6Id()).getCategoryName());

					}
				}
			} catch (SQLException | NamingException e) {
				throw new ServletException(e);

			}
			if (SpotName != null) {

				request.setAttribute("spotList", newList);
				request.setAttribute("SpotInf", tmpId);
				request.setAttribute("addedSpotInf", tmpId);

			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		String url = ConstURL.SEARCH_AND_DISPLAY_SPOT_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}
}
