package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import constants.ConstURL;

/**
 * 予約画面（ログイン後）表示用サーブレットP04011
 */
@WebServlet("/DisplayReservationServlet")
public class DisplayReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		String url = ConstURL.DISPLAY_RESERVATION_PATH;

		String memberId = (String) session.getAttribute("userId_tmp");

		String ItineraryId = request.getParameter("itineraryId");
		String ItineraryName = request.getParameter("itineraryName");
		System.out.println("------itineraryId------");
		System.out.println(ItineraryId);
		System.out.println("------itineraryId------");


		if (!(ItineraryId==null || ItineraryId.isEmpty())) {
			Product product=new Product();
			product.setProductId(ItineraryId);
			product.setProductName(ItineraryName);
			session.setAttribute("product", product);
			request.setAttribute("ItineraryId", ItineraryId);
			request.setAttribute("ItineraryName", ItineraryName);

		}


		System.out.println(memberId);
		if (memberId == null) {
			String notLoginUrl = ConstURL.DISPLAY_USER_LOGIN_PATH;
			request.getRequestDispatcher("/WEB-INF/P01021.jsp").forward(request, response);
			return;
		}





		request.getRequestDispatcher(url).forward(request, response);
	}
}
