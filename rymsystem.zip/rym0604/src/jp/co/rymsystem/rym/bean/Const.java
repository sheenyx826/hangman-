package jp.co.rymsystem.rym.bean;

public class Const {

	public static final String EMPLOYEE_FILE_PATH = "C:\\Users\\MIZUHO\\Desktop\\employee.txt";
	public static final String COMPANY_FILE_PATH = "C:\\Users\\MIZUHO\\Desktop\\company.csv";
	public static final String Product_FILE_PATH = "C:\\Users\\MIZUHO\\Desktop\\product.txt";
	public static final String Sale_FILE_PATH = "C:\\Users\\MIZUHO\\Desktop\\sale.txt";

}
