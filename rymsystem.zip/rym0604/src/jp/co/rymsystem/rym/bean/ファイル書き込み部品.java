package jp.co.rymsystem.rym.bean;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ファイル書き込み部品 {

	private FileWriter frd;
	private BufferedWriter bufferedWriter;

	public ファイル書き込み部品(String filepath, boolean append) throws IOException {
		this.frd = new FileWriter(filepath, append);
		this.bufferedWriter = new BufferedWriter(this.frd);

	}

	public ファイル書き込み部品(String filepath) throws IOException {
		this(filepath, true);
	}

	public void write(String line) throws IOException {
		this.bufferedWriter.write(line);
	}

	public void close() throws IOException {
		this.bufferedWriter.close();
		this.frd.close();
	}

}