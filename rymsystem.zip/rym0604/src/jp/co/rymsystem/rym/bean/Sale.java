package jp.co.rymsystem.rym.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Sale {

	// saleNoのみequals設定済み

	String saleNo;
	String productNo;
	String productName;

	String storeNo;
	String storeName;
	String customerId;
	String customerName;
	String saleDate;
	String saleAmount;
	int salePrice;
	int subtotalPrice;
	private ファイル書き込み部品 writeFile;

	public Sale(String lineString) {
		String[] split = lineString.split(",");

		this.saleNo = split[0];
		this.productNo = split[1];
		this.productName = split[2];
		this.storeNo = split[3];
		this.storeName = split[4];
		this.customerId = split[5];
		this.customerName = split[6];
		this.saleDate = split[7];
		this.saleAmount = split[8];
		this.salePrice = Integer.parseInt(split[9]);
		this.subtotalPrice = Integer.parseInt(split[10]);

	}

	public List<Sale> selectAll() throws IOException {
		List<Sale> saleList = new ArrayList<Sale>();
		ファイル読み込み部品 reader = new ファイル読み込み部品(Const.Sale_FILE_PATH);
		List<String> filestring = reader.readFile();
		for (String lineString : filestring) {
			Sale sale = new Sale(lineString);
			saleList.add(sale);
		}
		reader.close();
		return saleList;
	}

	public String getSaleNo() {
		return saleNo;
	}

	public void setSaleNo(String saleNo) {
		this.saleNo = saleNo;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getSaleDate() {
		return saleDate;
	}

	public void setSaleDate(String saleDate) {
		this.saleDate = saleDate;
	}

	public String getSaleAmount(String saleAmount) {
		return saleAmount;
	}

	public void setSaleAmount(String saleAmount) {
		this.saleAmount = saleAmount;
	}

	public int getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(int salePrice) {
		this.salePrice = salePrice;
	}

	public int getsubotalPrice() {
		return subtotalPrice;
	}

	public void setsubotalPrice(int subtotalPrice) {
		this.subtotalPrice = subtotalPrice;
	}

	public Sale() {
	}

	public String createLineString() {
		return this.saleNo + "," + this.productNo + "," + this.productName + "," + this.storeNo + "," + this.storeNo
				+ "," + this.storeName + "," + this.customerId + "," + this.customerName + "," + this.saleDate + ","
				+ this.saleAmount + "," + this.salePrice + "," + this.subtotalPrice + "\n";
	}

	public void insert() throws IOException {
		this.writeFile = new ファイル書き込み部品(Const.Sale_FILE_PATH);
		writeFile.write(createLineString());
		writeFile.close();
	}
}
