package jp.co.rymsystem.rym.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class bean {

	private String number;
	private String name;
	private ファイル書き込み部品 writeFile;

	public bean() {
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public ファイル書き込み部品 getWriteFile() {
		return writeFile;
	}

	public void setWriteFile(ファイル書き込み部品 writeFile) {
		this.writeFile = writeFile;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<bean> selectAll() throws IOException {
		List<bean> companys = new ArrayList<bean>();
		ReaderFile reader = new ReaderFile(Const.COMPANY_FILE_PATH);
		List<String> filestring = reader.readFile();
		for (String lineString : filestring) {
			bean company = new bean(lineString);
			// 一行ずつproductsリストに
			companys.add(company);
		}
		reader.close();
		return companys;
	}

	public bean(String lineString) {
		String[] split = lineString.split(",");

		this.number = split[0];
		this.name = split[1];

	}

	public String createLineString() {
		return this.number + "," + this.name + "\n";
	}

	public void insert() throws IOException {
		this.writeFile = new ファイル書き込み部品(Const.COMPANY_FILE_PATH);
		writeFile.write(createLineString());
		writeFile.close();
	}

}
