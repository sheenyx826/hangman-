package jp.co.rymsystem.rym.bean;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Productbeans {
	private String productNo;
	private String productName;
	private BigDecimal productprice;
	private ファイル書き込み部品 writeFile;
	private ファイル読み込み部品 readFile;

	public Productbeans() {

	}

	public Productbeans(String productNo, String productName, BigDecimal productprice, ファイル書き込み部品 writeFile,
			ファイル読み込み部品 readFile) {
		this.productNo = productNo;
		this.productName = productName;
		this.productprice = productprice;
		this.writeFile = writeFile;
		this.readFile = readFile;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public BigDecimal getProductprice() {
		return productprice;
	}

	public void setProductprice(BigDecimal productprice) {
		this.productprice = productprice;
	}

	public ファイル書き込み部品 getWriteFile() {
		return writeFile;
	}

	public void setWriteFile(ファイル書き込み部品 writeFile) {
		this.writeFile = writeFile;
	}

	public ファイル読み込み部品 getReadFile() {
		return readFile;
	}

	public void setReadFile(ファイル読み込み部品 readFile) {
		this.readFile = readFile;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		int No = Integer.parseInt(productNo);
		result = prime * result + No;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Productbeans other = (Productbeans) obj;
		if (productNo != other.productNo)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [productNo=" + productNo + ", productName=" + productName + ", productprice=" + productprice
				+ "]";
	}

	public Productbeans(String lineString) {
		String[] split = lineString.split(",");

		this.productNo = split[0];
		this.productName = split[1];
		this.productprice = new BigDecimal(split[2]);

	}

	public List<Productbeans> selectAll() throws IOException {
		List<Productbeans> products = new ArrayList<Productbeans>();
		ファイル読み込み部品 reader = new ファイル読み込み部品(Const.Product_FILE_PATH);
		List<String> filestring = reader.readFile();
		for (String lineString : filestring) {
			Productbeans product = new Productbeans(lineString);
			products.add(product);
		}
		reader.close();
		return products;
	}

	public Productbeans selectByMyEmployeeNo() throws IOException {
		Productbeans product = new Productbeans(this.productNo);
		List<Productbeans> products = this.selectAll();
		for (Productbeans e : products) {
			if (e.equals(product)) {
				return e;
			}
		}
		return null;
	}

	public String createLineString() {
		return this.productNo + "," + this.productName + "," + this.productprice + "\n";
	}

	public void insert() throws IOException {
		this.writeFile = new ファイル書き込み部品(Const.Product_FILE_PATH);
		writeFile.write(createLineString());
		writeFile.close();
	}

	public void delete() throws IOException {
		this.writeFile = new ファイル書き込み部品(Const.Product_FILE_PATH, false);
		writeFile.close();
	}
}
