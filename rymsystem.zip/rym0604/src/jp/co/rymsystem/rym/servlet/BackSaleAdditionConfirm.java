package jp.co.rymsystem.rym.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.rymsystem.rym.bean.Sale;

/**
 * Servlet implementation class backSaleEdit
 */
@WebServlet("/BackSaleAdditionConfirm")
public class BackSaleAdditionConfirm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BackSaleAdditionConfirm() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	// !!!!!!!!!!!!!!!!!!!!!
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");

		ArrayList<Sale> saleList = (ArrayList<Sale>) session.getAttribute("Sale");
		if (session.getAttribute("Sale") == null) {
			saleList = new ArrayList<Sale>();
		}
		String saleNo = request.getParameter("saleNo");
		String productNo = request.getParameter("productNo");
		String productName = request.getParameter("productName");
		String storeNo = request.getParameter("storeNo");
		String storeName = request.getParameter("storeName");
		String customerId = request.getParameter("customerId");
		String customerName = request.getParameter("customerName");
		String saleDate = request.getParameter("saleDate");
		String saleAmount = request.getParameter("saleAmount");
		String salePrice = request.getParameter("salePrice");
		String subtotalPrice = request.getParameter("subtotalPrice");

		Sale sale = new Sale();

		sale.setSaleNo(saleNo);
		sale.setProductNo(productNo);
		sale.setProductName(productName);
		sale.setStoreNo(storeNo);
		sale.setStoreName(storeName);
		sale.setCustomerId(customerId);
		sale.setCustomerName(customerName);
		sale.setSaleDate(saleDate);
		sale.setSaleAmount(saleAmount);
		sale.setSalePrice(Integer.parseInt(salePrice));
		sale.setsubotalPrice(Integer.parseInt(subtotalPrice));

		sale.insert();
		saleList.add(sale);

		session.setAttribute("Sale", saleList);

		request.getRequestDispatcher("/WEB-INF/pages/saleAdditionConfirm.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
