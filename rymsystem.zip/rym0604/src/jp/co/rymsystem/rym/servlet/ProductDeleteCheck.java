package jp.co.rymsystem.rym.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.rymsystem.rym.bean.Productbeans;

/**
 * Servlet implementation class CompanyDeleteCheck
 */
@WebServlet("/ProductDeleteCheck")
public class ProductDeleteCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductDeleteCheck() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession();
		List<Productbeans> productList = (List<Productbeans>) session.getAttribute("productList");

		String check = request.getParameter("deli");

		if (check == null) {
			String message = "選択してください。";
			request.setAttribute("message", message);
			request.getRequestDispatcher("/WEB-INF/pages/Product.jsp").forward(request, response);
			return;
		}
		int deli = Integer.parseInt(request.getParameter("deli"));
		productList.remove(deli);
		new Productbeans().delete();
		for (Productbeans p : productList) {
			p.insert();
		}

		session.setAttribute("productList", productList);
		request.getRequestDispatcher("/WEB-INF/pages/ProductDeleteCheck.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
