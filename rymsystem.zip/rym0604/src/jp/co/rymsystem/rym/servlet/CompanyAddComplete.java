package jp.co.rymsystem.rym.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.rymsystem.rym.bean.bean;

/**
 * Servlet implementation class CompanyAddComplete
 */
@WebServlet("/CompanyAddComplete")
public class CompanyAddComplete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CompanyAddComplete() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();

		bean newdata = new bean();
		String name = (String) session.getAttribute("name");
		String number = (String) session.getAttribute("number");
		newdata.setName(name);
		newdata.setNumber(number);

		newdata.insert();

		request.getRequestDispatcher("/WEB-INF/pages/CompanyAddComplete.jsp").forward(request, response);
	}
}
