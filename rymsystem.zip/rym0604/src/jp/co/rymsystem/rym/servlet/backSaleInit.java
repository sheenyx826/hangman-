package jp.co.rymsystem.rym.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class backSaleInit
 */
@WebServlet("/backSaleInit")
public class backSaleInit extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public backSaleInit() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	// パスワードの精査する。そのあとに一覧
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		// /*ArrayList<Sale> productList = new ArrayList<Sale>();
		//
		// // ファイル読み込み
		// try (FileInputStream readFile = new FileInputStream(new
		// Const().Sale_FILE_PATH);
		// InputStreamReader changedFile = new InputStreamReader(readFile, "UTF-8");
		// BufferedReader br = new BufferedReader(changedFile);) {
		// // 売り上げ情報ファイルから1行読み込み
		// String line = br.readLine();
		// // 1行をproductクラスにsetterでセット
		// while (line != null) {
		//
		// // 一行を","ごとで"tokens"配列にしまう
		// String[] tokens = line.split(",");
		// String productCode = tokens[0];
		// String productName = tokens[1];
		// BigDecimal productPrice = new BigDecimal(tokens[2]);
		// // 読み込んだ一行を分割して変数に代入済み
		//
		// Product productClass = new Product();
		//
		// productClass.setProductCode(productCode);
		// productClass.setProductName(productName);
		// productClass.setProductPrice(productPrice);
		//
		// productList.add(productClass);
		//
		// line = br.readLine();
		// }
		// } catch (RuntimeException e) {
		// // 握りつぶし防止
		// e.printStackTrace();
		// }
		//
		// session.setAttribute("Product", productList);
		//
		// request.getRequestDispatcher("/WEB-INF/pages/productSelection.jsp").forward(request,
		// response);*/
		request.getRequestDispatcher("/WEB-INF/pages/backSaleInit.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
