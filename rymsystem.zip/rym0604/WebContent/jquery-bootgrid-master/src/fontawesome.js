$.extend($.fn.bootgrid.Constructor.defaults.css, {
    icon: "icon fa",
    iconColumns: "fa-th-list",
    iconDown: "fa-sort-desc",
    iconRefresh: "fa-refresh",
    iconSearch: "fa-search",
    iconUp: "fa-sort-asc"
});