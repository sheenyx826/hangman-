package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Employee;
import bean.EmployeeTmp;
import constants.ConstURL;
import dao.EmployeesDAO;
import dao.StatisticsInfoDAO;
import ds.ConnectionManager;

/**
 * 従業員情報登録用サーブレット
 */
@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = ConstURL.InsertDone_PATH;
		String errorURL = ConstURL.InsertInput_PATH;
		String errorMessage = "入力した従業員IDはすでに使用されています。";
		String Id = request.getParameter("txtId");
		String Name = request.getParameter("txtName");
		String AgeString = request.getParameter("txtAge");

		EmployeeTmp employeeTmp = new EmployeeTmp();

		employeeTmp.setId(Id);
		employeeTmp.setName(Name);
		employeeTmp.setAge(AgeString);

		if (Id == null || Id.isEmpty()) {
			if (Name == null || Name.isEmpty()) {
				if (AgeString == null || AgeString.isEmpty()) {
					String error = "従業員ID、従業員名、従業員年齢の入力文字が空です。";
					request.setAttribute("error", error);
					request.setAttribute("employee", employeeTmp);
					request.getRequestDispatcher(errorURL).forward(request, response);
					return;
				}
				String error = "従業員ID、従業員名の入力文字が空です。";
				request.setAttribute("error", error);
				request.setAttribute("employee", employeeTmp);
				request.getRequestDispatcher(errorURL).forward(request, response);
				return;
			}

			if (AgeString == null || AgeString.isEmpty()) {
				String error = "従業員ID、従業員年齢の入力文字が空です。";
				request.setAttribute("error", error);
				request.setAttribute("employee", employeeTmp);
				request.getRequestDispatcher(errorURL).forward(request, response);
				return;
			}

			String error = "従業員IDの入力文字が空です。";
			request.setAttribute("error", error);
			request.setAttribute("employee", employeeTmp);
			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		if (Name == null || Name.isEmpty()) {

			if (AgeString == null || AgeString.isEmpty()) {
				String error = "従業員名、従業員年齢の入力文字が空です。";
				request.setAttribute("error", error);
				request.setAttribute("employee", employeeTmp);
				request.getRequestDispatcher(errorURL).forward(request, response);
				return;
			}
			String error = "従業員名の入力文字が空です。";
			request.setAttribute("error", error);
			request.setAttribute("employee", employeeTmp);
			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		if (AgeString == null || AgeString.isEmpty()) {
			String error = "従業員年齢の入力文字が空です。";
			request.setAttribute("error", error);
			request.setAttribute("employee", employeeTmp);
			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		Pattern patternAny8Character = Pattern.compile("[0-9a-zA-Z]{8}");

		Matcher matcherAny8Character = patternAny8Character.matcher(Id);

		Pattern patternAny40Character = Pattern.compile(".{1,40}");

		Matcher matcherAny40Character = patternAny40Character.matcher(Name);

		Pattern pattern3Number = Pattern.compile("[0-9]{1,3}");

		Matcher matcherAny3Number = pattern3Number.matcher(AgeString);

		if (!matcherAny8Character.matches() || !matcherAny40Character.matches() || !matcherAny3Number.matches()) {
			if (!matcherAny8Character.matches()) {
				String error = "入力された従業員IDの文字列「" + Id + "」は半角英数字8桁ではありません。";
				request.setAttribute("errorId", error);
			}

			if (!matcherAny40Character.matches()) {
				String error = "入力された従業員名の文字列「" + Name + "」は40文字以内ではありません。";
				request.setAttribute("errorName", error);
			}

			if (!matcherAny3Number.matches()) {
				String error = "入力された従業員年齢の文字列「" + AgeString + "」は半角数字3桁以内ではありません。";
				request.setAttribute("errorAge", error);
			} else {
				if (Integer.parseInt(request.getParameter("txtAge")) < 15
						|| Integer.parseInt(request.getParameter("txtAge")) > 100) {
					String error = "入力された従業員年齢は「" + AgeString + "」は15～100歳ではありません。";
					request.setAttribute("errorAgeArrange", error);

				}
			}
			request.setAttribute("employee", employeeTmp);

			request.getRequestDispatcher(errorURL).forward(request, response);
			return;

		}

		if (Integer.parseInt(request.getParameter("txtAge")) < 15
				|| Integer.parseInt(request.getParameter("txtAge")) > 100) {
			String error = "入力された従業員年齢は「" + AgeString + "」は15～100歳ではありません。";
			request.setAttribute("errorAgeArrange", error);
			request.setAttribute("employee", employeeTmp);

			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		int Age = Integer.parseInt(request.getParameter("txtAge"));

		try (Connection con = ConnectionManager.getConnection()) {
			con.setAutoCommit(false);
			try {
				Employee employee = new Employee();
				employee.setId(Id);
				employee.setName(Name);
				employee.setAge(Age);
				EmployeesDAO dao = new EmployeesDAO(con);
				dao.insert(employee);
				request.setAttribute("employee", employee);

				StatisticsInfoDAO staDao = new StatisticsInfoDAO(con);
				staDao.insert();
				con.commit();
			} finally {
				try {
					con.rollback();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} catch (NamingException | SQLException e) {
			if (((SQLException) e).getErrorCode() == 1) {
				request.setAttribute("employee", employeeTmp);

				request.setAttribute("error", errorMessage);
				url = errorURL;
			} else {
				throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");

			}
		}

		request.getRequestDispatcher(url).forward(request, response);

	}
}
