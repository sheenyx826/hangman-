package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Member;

/**
 * テンプレートテーブルを管理するクラス。
 *
 * @author yokin
 */
public class MembersDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */
	public MembersDAO(Connection con) {
		this.con = con;
	}

	/**
	 * 会員情報全件検索
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<Member> selectAll() throws SQLException {
		String sql = "SELECT * FROM MEMBERS ORDER BY MEMBER_ID";
		List<Member> list = new ArrayList<Member>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Member member = new Member();
				member.setId(rs.getString("MEMBER_ID"));
				member.setName(rs.getString("MEMBER_NAME"));
				member.setSpell(rs.getString("MEMBER_SPELL"));
				member.setPostcode(rs.getString("MEMBER_POSTCODE"));
				member.setAddress(rs.getString("MEMBER_ADDRESS"));
				member.setPhoneNumber(rs.getString("MEMBER_PHONENUMBER"));
				member.setBirthday(rs.getDate("MEMBER_BIRTHDAY"));
				list.add(member);
			}
		}
		return list;
	}

	public List<Member> selectById(String id) throws SQLException {
		String sql = "SELECT *FROM MEMBERS WHERE MEMBER_ID LIKE '%'||?||'%' ";
		List<Member> list = new ArrayList<Member>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Member member = new Member();
					member.setId(rs.getString("MEMBER_ID"));
					member.setName(rs.getString("MEMBER_NAME"));
					member.setSpell(rs.getString("MEMBER_SPELL"));
					list.add(member);
				}
			}
		}
		return list;
	}

	public Member confirmById(String id) throws SQLException {
		String sql = "SELECT * FROM MEMBERS WHERE MEMBER_ID =? ";
		Member member = null;

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					member = new Member();
					member.setId(rs.getString("MEMBER_ID"));
					member.setName(rs.getString("MEMBER_NAME"));
					member.setSpell(rs.getString("MEMBER_SPELL"));
					member.setBirthday(rs.getDate("BIRTHDAY"));
					member.setPostcode(rs.getString("POSTCODE"));
					member.setPhoneNumber(rs.getString("PHONENUMBER"));
					member.setSex(rs.getString("SEX"));
					member.setAddress(rs.getString("ADDRESS"));
				}
			}
		}
		return member;
	}

	public Member confirmById1(String id) throws SQLException {
		Member member = null;
		String sql = "SELECT * FROM MEMBERS WHERE MEMBER_ID = ?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					member = new Member();
					member.setId(rs.getString("MEMBER_ID"));
					member.setName(rs.getString("MEMBER_NAME"));
					member.setSpell(rs.getString("MEMBER_SPELL"));
					member.setBirthday(rs.getDate("BIRTHDAY"));
					member.setPostcode(rs.getString("POSTCODE"));
					member.setPhoneNumber(rs.getString("PHONENUMBER"));
					member.setSex(rs.getString("SEX"));
					member.setAddress(rs.getString("ADDRESS"));
				}
			}
		}
		return member;
	}

	public List<Member> selectByCondition(String name, String spell, String sex, int[] age) throws SQLException {
		String sql = "SELECT MEMBER_ID,MEMBER_NAME,MEMBER_SPELL,SEX,TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1) FROM MEMBERS WHERE MEMBER_NAME LIKE '%'||?||'%' AND MEMBER_SPELL LIKE '%'||?||'%' AND SEX LIKE '%'||?||'%' AND (TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=? OR TRUNC((TO_CHAR(SYSDATE, 'YYYYMMDD') - TO_CHAR(BIRTHDAY, 'YYYYMMDD')) / 10000, -1)=?)  ";
		List<Member> list = new ArrayList<Member>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, name);
			ps.setString(2, spell);
			ps.setString(3, sex);

			ps.setInt(4, age[0]);
			ps.setInt(5, age[1]);
			ps.setInt(6, age[2]);
			ps.setInt(7, age[3]);
			ps.setInt(8, age[4]);
			ps.setInt(9, age[5]);
			ps.setInt(10, age[6]);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Member member = new Member();
					member.setId(rs.getString("MEMBER_ID"));
					member.setName(rs.getString("MEMBER_NAME"));
					member.setSpell(rs.getString("MEMBER_SPELL"));
					list.add(member);
				}
			}
		}
		return list;
	}

}