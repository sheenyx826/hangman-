package bean;

import java.io.Serializable;

/**
 * @author yokin エラーの時、従業員の入力情報を保持するBean
 */
public class EmployeeTmp implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * 従業員ID
	 */
	private String id;
	/**
	 * 従業員名
	 */
	private String name;
	/**
	 * String型従業員年齢
	 */
	private String age;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "EmployeeTmp [id=" + id + ", name=" + name + ", age=" + age + "]";
	}

}
