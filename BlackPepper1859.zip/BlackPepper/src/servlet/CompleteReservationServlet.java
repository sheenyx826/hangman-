package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import bean.Product;
import bean.Reservation;
import constants.ConstURL;
import constants.RankAndPoint;
import dao.MembersDAO;
import dao.ReservationDAO;
import ds.ConnectionManager;

/**
 * 予約完了画面表示用サーブレットP04012
 */
@WebServlet("/CompleteReservationServlet")
public class CompleteReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.COMPLETE_RESERVATION_PATH;

		HttpSession session = request.getSession();
		String productId = (String) session.getAttribute("productId");
		String ItineraryId = request.getParameter("itineraryId");

		String adultCount = (String) session.getAttribute("adultCount");
		String childCount = (String) session.getAttribute("childCount");
		int inttotalAmount = Integer.parseInt(adultCount) + Integer.parseInt(childCount);
		Timestamp date = new Timestamp(new Date().getTime());
		String memberId = (String) session.getAttribute("userId_tmp");

		int cnt = 0;
		try (Connection con = ConnectionManager.getConnection()) {

			ReservationDAO reservationDAO = new ReservationDAO(con);
			Reservation reservation = new Reservation();

			String reservationId = date + memberId;
			// Timestamp reservationTime = date;
			// **TODO reservationNumberどう持ってきたらいいのか分からない

			Product product = (Product) session.getAttribute("product");

			String totalAmount = String.valueOf(inttotalAmount);
			String paymentMethod = request.getParameter("payment");
			String creditcardNumber = request.getParameter("cardNo");
			String expiryDate = request.getParameter("expiryDate");

			String productPrice = product.getProductPrice();

			String airportTax = product.getAirportTax();
			String currencyUnit = product.getCurrencyUnit();
			String exchangeRate = product.getExchangeRate();
			String itineraryId = request.getParameter("itineraryId");
			String departureFlightId = request.getParameter("departureFlightId");
			String arrivalFlightId = request.getParameter("arrivalFlightId");

			reservation.setReservationId(reservationId);
			if (ItineraryId == null || ItineraryId.isEmpty()) {
				reservation.setProductId(productId);
				System.out.println("------productId------");
				System.out.println(productId);
				System.out.println("------productId------");
				System.out.println("------itineraryId------");
				System.out.println(itineraryId);
				System.out.println("------itineraryId------");

			} else {
				reservation.setItineraryId(itineraryId);
				System.out.println("------productId------");
				System.out.println(productId);
				System.out.println("------productId------");
				System.out.println("------itineraryId------");
				System.out.println(itineraryId);
				System.out.println("------itineraryId------");
			}

			// reservationBeanに各項目追加
			String ProductId_tmp = product.getProductId();
			if (itineraryId != null) {
				ProductId_tmp = null;

			}
			reservation.setProductId(ProductId_tmp);
			reservation.setMemberId(memberId);
			reservation.setReservationTime(date);
			reservation
					.setReservationNumber(String.valueOf((Integer.parseInt((String) session.getAttribute("adultCount"))
							+ Integer.parseInt((String) session.getAttribute("childCount")))));

			// reservation.setReservationNumber();
			Timestamp dateStt = new Timestamp(new Date().getTime());
			String stt = dateStt.toString();
			if (product.getDepartureTime() != null) {
				final Timestamp timestamp = product.getDepartureTime();
				stt = timestamp.toString();

			}
			reservation.setDepartureDay(stt);

			reservation.setItineraryId(itineraryId);
			reservation.setPaymentMethod(paymentMethod);
			reservation.setCreditcardNumber(creditcardNumber);
			reservation.setExpiryDate(expiryDate);
			reservation.setProductPrice(product.getProductPrice());
			reservation.setAirportTax(product.getAirportTax());
			// reservation.setCurrenyUnit(currenyUnit);
			reservation.setExchangeRate(product.getExchangeRate());
			reservation.setTotalAmount(String.valueOf(session.getAttribute("totalPrice")));

			reservation.setDepartureFlightId(departureFlightId);

			reservation.setArrivalFlightId(arrivalFlightId);

			// reservationDAOにinsertする
			cnt = reservationDAO.insert(reservation);

			// 予約が完了したらユーザーポイントを加算する
			if (cnt == 1) {

				// メンバーIDをもとにメンバーbean生成
				Member member = (Member) session.getAttribute("afterloginmember");

				// sessionからログインユーザをgetする
				int newUserPoint = RankAndPoint.addUserPointByReservation(member.getUserPoint());
				// メンバーにnewUserPointをセット
				member.setUserPoint(newUserPoint);
				// MemberDAOをnew する
				MembersDAO membersDAO = new MembersDAO(con);
				// MemberDAOのポイント加算メソッドを呼び出す
				membersDAO.addPoint(member);
				// - MemberDAOにポイント加算メソッドをつくっとくひつようがある
				// - update member set point = ? where member_id = ?
				// - 1こめの?にnewUserPoint２こめの?にログインユーザのID

				// member.setUserPoint(newUserPoint);

			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			throw new ServletException(e);
		}
		String howtopay = (String) session.getAttribute("howtopay");
		System.out.println(howtopay);
		if (howtopay.equals("銀行振り込み")) {
			System.out.println("成功");
			request.setAttribute("whenPaymentIsBank", "振り込み先に関しましてはご登録いただいているメールアドレスにメール送信しました。");
		}
		System.out.println(cnt);
		request.getRequestDispatcher(url).forward(request, response);

	}
}
