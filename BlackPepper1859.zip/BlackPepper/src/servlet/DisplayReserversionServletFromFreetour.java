package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Fright;
import bean.Itinerary;
import bean.Product;
import bean.SpotInf;
import constants.ConstURL;
import dao.FrightDAO;
import dao.ItineraryDAO;
import dao.SpotInfDAO;
import ds.ConnectionManager;

/**
 * Servlet implementation class DisplayReserversionServletFromFreetour
 */
@WebServlet("/DisplayReserversionServletFromFreetour")
public class DisplayReserversionServletFromFreetour extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		System.out.println("DisplayReserversionServletFromFreetour入った");
		String memberId = (String) session.getAttribute("userId_tmp");

		String ItineraryId = request.getParameter("itineraryId");
		String ItineraryName = request.getParameter("itineraryName");

		// チェック
		System.out.println("------itineraryId------");
		System.out.println(ItineraryId);
		System.out.println("------itineraryId------");

		// いらんけど一応残す
		if (!(ItineraryId == null || ItineraryId.isEmpty())) {
			Product product = new Product();
			product.setProductId(ItineraryId);
			product.setProductName(ItineraryName);
			session.setAttribute("product", product);
			request.setAttribute("ItineraryId", ItineraryId);
			request.setAttribute("ItineraryName", ItineraryName);

		}

		System.out.println(memberId);
		if (memberId == null) {
			String notLoginUrl = ConstURL.DISPLAY_USER_LOGIN_PATH;
			request.getRequestDispatcher("/WEB-INF/P01021.jsp").forward(request, response);
			return;
		}

		Itinerary itinerary = new Itinerary();
		List<SpotInf> selectByItineraryIdReturnPrice = new ArrayList<SpotInf>();
		List<Fright> flightListFirst = new ArrayList<>();
		List<Fright> flightListLast = new ArrayList<>();
		int total = 0;

		try (Connection con = ConnectionManager.getConnection();) {

			/**
			 * 手順。旅日記IDをもとに １、オプショナルツアーリスト作成、それの合計金額出す（まだ一人当たりでＯＫ） ２、飛行機リストを作成。国をもとにして検索
			 *
			 */
			ItineraryDAO itineraryDAO = new ItineraryDAO(con);
			SpotInfDAO spotInf = new SpotInfDAO(con);

			itinerary = itineraryDAO.selectByItineraryId(ItineraryId);
			System.out.println(itinerary + "selectByしたときのtostring");
			// 金額入りの旅程表項目が出てくる
			selectByItineraryIdReturnPrice = spotInf.selectByItineraryIdReturnPrice(itinerary.getItineraryId());
			for (SpotInf fright : selectByItineraryIdReturnPrice) {
				System.out
						.println("Integer.parseInt(fright.getTourPrice()):" + Integer.parseInt(fright.getTourPrice()));
				total += Integer.parseInt(fright.getTourPrice());
			}
			session.setAttribute("totalpppp", total);

			System.out.println("flightDAO作成前");
			FrightDAO frightDAO = new FrightDAO(con);
			//			 1は東京のID,3はデリーのID
			//			 行きは出発日本、到着現地。帰りは逆でそれぞれのフライト検索
			System.out.println("一個目");
			flightListFirst = frightDAO.selectByCityId(1, 3);
			System.out.println("に個目");
			flightListLast = frightDAO.selectByCityId(3, 1);

		} catch (NamingException e) {
			throw new ServletException(e);
		} catch (SQLException e) {
			throw new ServletException(e);

		}
		session.setAttribute("totalpppp", total);

		session.setAttribute("selectByItineraryIdReturnPrice", selectByItineraryIdReturnPrice);
		// System.out.println(selectByItineraryIdReturnPrice.get(0).getTourPrice());

		System.out.println(selectByItineraryIdReturnPrice.size());

		session.setAttribute("flightListFirst", flightListFirst);
		System.out.println("kokogadaiji111111");

		System.out.println(flightListFirst.size());
		System.out.println(flightListFirst.get(0));
		System.out.println("kokogadaiji222222");
		session.setAttribute("flightListLast", flightListLast);
		System.out.println(flightListLast.size());

		request.getRequestDispatcher("/WEB-INF/P04011F.jsp").forward(request, response);
	}
}
