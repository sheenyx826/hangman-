package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constants.ConstURL;

/**
 * フリーツアー 国・泊数選択画面表示用サーブレット
 */
@WebServlet("/SelectFreeTourServlet")
public class SelectFreeTourServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		for (int i = 1; i < 82; i++) {
			String key1 = "spotName" + String.valueOf(i);
			String key2 = "tourName" + String.valueOf(i);
			String key3 = "tourPrice" + String.valueOf(i);
			session.removeAttribute(key1);
			session.removeAttribute(key2);
			session.removeAttribute(key3);
		}

		String url = ConstURL.SELECT_FREE_TOUR_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}
}
