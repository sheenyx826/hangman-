package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import constants.ConstURL;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * ログイン検証用サーブレット
 */
@WebServlet("/ValidateUserLoginServlet")
public class ValidateUserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("サーブレットIN");

		HttpSession session = request.getSession();

		// TODO ログイン後の遷移先はそれぞれ異なる。どこにする？
		int loginFlag = 0;
		String url = ConstURL.VALIDATE_USER_LOGIN_PATH;

		String inputId = request.getParameter("id");
		String inputPassword = request.getParameter("pass");
		System.out.println(inputId + "," + inputPassword);

		// // 入力検証
		// // idが無かった時のエラー
		// if (inputId == null || inputId.isEmpty()) {
		//
		// String error = "IDが入力されていません。";
		// request.setAttribute("errorMessage", error);
		// url = ConstURL.DISPLAY_USER_LOGIN_PATH;
		// request.getRequestDispatcher(url).forward(request, response);
		// return;
		// }
		//
		// Pattern patternNumber = Pattern.compile("[1-9]");
		// Matcher matcherNumber = patternNumber.matcher(inputId);
		//
		// if (!matcherNumber.matches()) {
		// String error = "IDが存在しません";
		// request.setAttribute("errorMessage", error);
		// url = ConstURL.DISPLAY_USER_LOGIN_PATH;
		// request.getRequestDispatcher(url).forward(request, response);
		// return;
		// }
		//
		// // パスワード未入力エラー
		// if (inputPassword == null || inputPassword.isEmpty()) {
		//
		// String error = "EMPLOYEE_NAMEが入力されていません";
		// request.setAttribute("errorMessage", error);
		// url = ConstURL.DISPLAY_USER_LOGIN_PATH;
		// request.getRequestDispatcher(url).forward(request, response);
		// return;
		// }

		System.out.println("入力検証チェック終了した体");

		// データベースにidがあるかどうか判断
		try (Connection con = ConnectionManager.getConnection()) {
			System.out.println("try文の中入った");
			// DAOにcon、ID、パスワードを渡してデータベース回す。後はDAOでIDない、IDあるけどパス違うの2ケース検証して、結果をフラッグで返す。
			MembersDAO membersDAO = new MembersDAO(con);
			System.out.println("チェックメソッド呼び出し");
			// IDとPassword一致してたらフラッグに1が入る
			loginFlag = membersDAO.checkLogin(inputId, inputPassword);
			System.out.println("チェックメソッド呼び出し終了" + "loginFlagは" + loginFlag);

			if (loginFlag == 1) {
				System.out.println("IF中");

				Member member = membersDAO.selectByMemberId(inputId);

				session.setAttribute("afterloginmember", member);
				session.setAttribute("userId", member.getName() + " 様");
				session.setAttribute("userId_tmp", inputId);
				System.out.println(inputId);
			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}

		if (loginFlag == 0) {
			session.setAttribute("userId", "未ログインです");
			request.setAttribute("missLogin", "ログインに失敗しました。ID、Passwordをお確かめください。");
			request.getRequestDispatcher("ViewTopPageServlet").forward(request, response);
			return;
		}
		System.out.println("ですぱっちゃ前");
		// request.getRequestDispatcher(url).forward(request, response);
		request.getRequestDispatcher("ViewTopPageServlet").forward(request, response);
	}

}
