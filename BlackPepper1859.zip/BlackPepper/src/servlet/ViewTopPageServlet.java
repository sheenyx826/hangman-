package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberTopThree;
import constants.ConstURL;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * トップページ画面表示用サーブレット
 */
@WebServlet("/ViewTopPageServlet")
public class ViewTopPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.VIEW_TOP_PAGE_PATH;
		HttpSession session = request.getSession();
		List<MemberTopThree> TopThreeL = new ArrayList<MemberTopThree>();
		MemberTopThree memberTop = new MemberTopThree();
		MemberTopThree memberSecond = new MemberTopThree();
		MemberTopThree memberThird = new MemberTopThree();
		try (Connection connection = ConnectionManager.getConnection();) {
			MembersDAO membersDAO = new MembersDAO(connection);

			TopThreeL = membersDAO.selectTopThree();
			// memberTop = TopThreeL.get(0);
			// memberSecond = TopThreeL.get(1);
			// memberThird = TopThreeL.get(2);
			// memberTop.setItineraryL(membersDAO.ItineraryListselectById(memberTop.getMemberId()));
			// memberSecond.setItineraryL(membersDAO.ItineraryListselectById(memberSecond.getMemberId()));
			// memberThird.setItineraryL(membersDAO.ItineraryListselectById(memberThird.getMemberId()));

			for (MemberTopThree memberTopThree : TopThreeL) {
				memberTopThree.setItineraryL(membersDAO.ItineraryListselectById(memberTopThree.getMemberId()));
				System.out.println(memberTopThree);

			}
			session.setAttribute("TopThreeL", TopThreeL);
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		session.setAttribute("memberTop", memberTop);
		session.setAttribute("memberSecond", memberSecond);
		session.setAttribute("memberThird", memberThird);
		System.out.println(memberTop);
		request.getRequestDispatcher(url).forward(request, response);
	}
}
