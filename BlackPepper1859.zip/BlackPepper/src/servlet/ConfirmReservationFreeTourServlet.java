package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Card;
import bean.Fright;
import bean.Reservation;
import dao.FrightDAO;
import ds.ConnectionManager;

/**
 * Servlet implementation class ConfirmReservationFreeTourServlet
 */
@WebServlet("/ConfirmReservationFreeTourServlet")
public class ConfirmReservationFreeTourServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// reservationBean/reservationDAOがある想定
		HttpSession session = request.getSession();
		Reservation reservation = null;

		String ItineraryId = request.getParameter("itineraryId");
		System.out.println("------itineraryId------");
		System.out.println(ItineraryId);
		System.out.println("------itineraryId------");

		String ItineraryName = request.getParameter("itineraryName");
		if (!(ItineraryId == null || ItineraryId.isEmpty())) {
			request.setAttribute("ItineraryId", ItineraryId);
			request.setAttribute("ItineraryName", ItineraryName);

		}
		//フライトのIDゲット
		String firstFlight = request.getParameter("firstFlight");
		Fright firstFright = null;
		String lastFlight = request.getParameter("lastFlight");
		Fright lastFright = null;

		System.out.println(session.getAttribute("id"));
		System.out.println("aaa");
		// 商品ＩＤ
		String productId = "1";
		String sql = "select * from product where product_id = ?";
		try (Connection con = ConnectionManager.getConnection()) {
			try (PreparedStatement ps = con.prepareStatement(sql)) {
			}
			// 大人人数
			String adultCount = request.getParameter("adultCount");
			session.setAttribute("adultCount", adultCount);

			// 子供人数
			String childCount = request.getParameter("childCount");
			session.setAttribute("childCount", childCount);

			// 出発日
			//			DateFormat formatter;
			//			formatter = new SimpleDateFormat("yyyy年MM月dd日");
			//			Date date = (Date) formatter.parse(request.getParameter("startDate"));
			//			java.sql.Timestamp timeStampDateFirst = new Timestamp(date.getTime());
			//			session.setAttribute("startdate", timeStampDateFirst);
			//			System.out.println(session.getAttribute("startdate"));

			String startdate = request.getParameter("startDate");
			session.setAttribute("startdate", startdate);

			String endDate = request.getParameter("endDate");
			session.setAttribute("endDate", endDate);

			// 戻り日
			//			DateFormat formatter2;
			//			formatter2 = new SimpleDateFormat("yyyy年MM月dd日");
			//			Date date2 = (Date) formatter2.parse(request.getParameter("endDate"));
			//			java.sql.Timestamp timeStampDateLast = new Timestamp(date.getTime());
			//			session.setAttribute("endDate", timeStampDateLast);
			//			System.out.println(session.getAttribute("endDate"));

			// 出発便
			String departure = request.getParameter("departure");
			session.setAttribute("departure", departure);

			// 到着便
			String arrival = request.getParameter("arrival");
			session.setAttribute("arrival", arrival);

			String payment = request.getParameter("payment");
			String howtopay;
			// 支払方法クレジットか銀行振り込みか？？？ちょっと良く分からない
			if (payment.equals("credit")) {
				howtopay = "クレジット";
			} else {
				howtopay = "銀行振込";
			}
			session.setAttribute("howtopay", howtopay);

			// カード情報

			String cardName = request.getParameter("cardName");
			String cardValidTermM = request.getParameter("cardValidTermM");
			String cardValidTermY = request.getParameter("cardValidTermY");
			String cardNo = request.getParameter("cardNo");
			String _cardSecCd2 = request.getParameter("_cardSecCd2");

			Card card = new Card();
			card.setCardName(cardName);
			card.setCardNo(cardNo);
			card.setCardValidTermM(cardValidTermM);
			card.setCardValidTermY(cardValidTermY);
			card.set_cardSecCd2(_cardSecCd2);
			session.setAttribute("card", card);

			// reservation = new Reservation();
			// reservation.setReservationId(productId);
			// reservation.setDepartureDay("start_date");
			// reservation.setDepartureFlightId("departure");
			// reservation.setArrivalFlightId("arrival");
			// reservation.setPaymentMethod(howtopay);
			System.out.println(reservation);

			//行きのフライト帰りのフライトをbeanにした。外でセッション入れる
			FrightDAO frightDAO = new FrightDAO(con);
			firstFright = frightDAO.selectByFlightId(firstFlight);
			lastFright = frightDAO.selectByFlightId(lastFlight);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		//		catch (ParseException e) {
		//			// TODO 自動生成された catch ブロック
		//			e.printStackTrace();
		//		}

		// 一人当たり空港使用税の計算。レートは固定で1.524
		double rate = 1.524;

		int airportTax = 1500;

		double ratedTax = rate * airportTax;
		System.out.println("一人当たり計算後税は" + ratedTax);
		double result = Math.floor(ratedTax);
		System.out.println("result" + result);
		//		if (product.getAirportTax() != null) {
		//			airportTax = Integer.parseInt(product.getAirportTax());
		//
		//		}
		//
		//		if (product.getExchangeRate() != null) {
		//			exchangeRate = Double.parseDouble(product.getExchangeRate());
		//
		//		}

		//オプショナルツアーの一人当たり価格と一人当たり空港税を計算
		double finalPricePerPerson = result + (int) session.getAttribute("totalpppp");

		System.out.println("finalPricePerPerson" + finalPricePerPerson);

		// 人数計算
		int adultCount = Integer.parseInt(request.getParameter("adultCount"));
		int childCount = Integer.parseInt(request.getParameter("childCount"));
		int totalCount = adultCount + childCount;
		System.out.println("totalcount" + totalCount);

		session.setAttribute("totalCountatConfirm", totalCount);

		// 最終金額計算セッションで飛ばす
		double totalPrice = totalCount * finalPricePerPerson;
		System.out.println("saigo切り捨て前" + totalPrice);
		int finalTotalPrice = (int) Math.floor(totalPrice);
		System.out.println("saigo切り捨て後" + totalPrice);

		session.setAttribute("totalPrice", finalTotalPrice);

		request.setAttribute("reservation", reservation);

		session.setAttribute("firstFright", firstFright);
		session.setAttribute("lastFright", lastFright);

		request.getRequestDispatcher("/WEB-INF/P04021F.jsp").forward(request, response);
	}

}
