package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Member;
import constants.ConstURL;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * ユーザー登録完了画面表示用サーブレット
 */
@WebServlet("/CompleteUserSignUpServlet")
public class CompleteUserSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = ConstURL.COMPLETE_USER_SIGN_UP_PATH;
		// Memberのインスタンス生成
		Member member = new Member();
		// ユーザー情報のパラメーター取得
		String name = request.getParameter("lastName") + " " + request.getParameter("firstName");
		String nameKana = request.getParameter("lastNameKana") + " " + request.getParameter("firstNameKana");
		String password = request.getParameter("password");
		String phoneNum = request.getParameter("phoneNum");
		String eMail = request.getParameter("eMail");
		String zip = request.getParameter("zip");
		String address = request.getParameter("address");
		// カード情報
		String creditCardNum = request.getParameter("creditCardNum");
		// カード期限
		String creditCardValidMonth = request.getParameter("creditCardValidMonth");
		String creditCardValidYear = request.getParameter("creditCardValidYear");

		String creditCardSecurityCord = request.getParameter("creditCardSecurityCord");
		String creditCardName = request.getParameter("creditCardName");
		// パスポート
		String passportName = request.getParameter("passportName");
		String passportNum = request.getParameter("passportNum");

		// Memberのインスタンスに情報をセット
		member.setName(name);
		member.setPassword(password);
		member.setPhoneNum(phoneNum);
		member.setZip(zip);
		member.setAddress(address);
		member.seteMail(eMail);
		member.setCreditCardName(creditCardName);
		member.setCreditCardNum(creditCardNum);
		member.setCreditCardSecurityCord(creditCardSecurityCord);
		member.setCreditCardValidMonth(creditCardValidMonth);
		member.setCreditCardValidYear(creditCardValidYear);
		member.setPassportName(passportName);
		member.setPassportNum(passportNum);

		try (Connection connection = ConnectionManager.getConnection();) {
			// ユーザー情報をＤＢに追加
			// DAOインスタンスの生成
			MembersDAO membersDAO = new MembersDAO(connection);
			membersDAO.insert(member);
			request.setAttribute("member", member);
			request.setAttribute("nameKana", nameKana);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
}
