package bean_sample;

import java.io.Serializable;
import java.sql.Timestamp;;

/**
 * @author yokin 統計情報Bean
 */
public class StatisticsInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * 更新時刻
	 */
	Timestamp updateTime;
	/**
	 * 従業員総数
	 */
	int amount;
	/**
	 * 従業員平均年齢
	 */
	int aveAge;

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getAveAge() {
		return aveAge;
	}

	public void setAveAge(int aveAge) {
		this.aveAge = aveAge;
	}

	@Override
	public String toString() {
		return "StatisticsInfo [updateTime=" + updateTime + ", amount=" + amount + ", aveAge=" + aveAge + "]";
	}

}
