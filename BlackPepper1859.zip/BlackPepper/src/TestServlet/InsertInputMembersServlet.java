package TestServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 従業員情報登録画面表示用サーブレット
 */
@WebServlet("/InsertInputMembersServlet")
public class InsertInputMembersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// String url = ConstURL.InsertInputMembers_PATH;
		// request.getRequestDispatcher(url).forward(request, response);

	}

}
