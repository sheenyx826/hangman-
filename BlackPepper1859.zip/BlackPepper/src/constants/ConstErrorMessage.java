package constants;

/**
 * @author エラーメッセージを保持するクラス
 *
 */
public class ConstErrorMessage {
	// NULLチェック用
	public static final String lastNameNullError = "名前(姓)を入力してください。";
	public static final String lastNameKanaNullError = "名前(セイ)を入力してください。";
	public static final String firstNameNullError = "名前(名)を入力してください。";
	public static final String firstNameKanaNullError = "名前(メイ)を入力してください。";
	public static final String passwordNullError = "パスワードを入力してください。";
	public static final String phoneNumNullError = "電話番号を入力してください。";
	public static final String eMailNullError = "メールアドレスを入力してください。";
	public static final String zipNullError = "郵便番号を入力してください。";
	public static final String passportNameNullError = "パスポート名義を入力してください。";
	public static final String passportNumNullError = "パスポート番号を入力してください。";

	// 入力値チェック用
	public static final String lastNameValueError = "名前(姓)を正しく入力してください。";
	public static final String lastNameKanaValueError = "名前(セイ)を正しく入力してください。";
	public static final String firstNameValueError = "名前(名)を正しく入力してください。";
	public static final String firstNameKanaValueError = "名前(メイ)を正しく入力してください。";
	public static final String nameKanaValueError = "名前(フリガナ)は全角カタカナ100文字以内で入力してください。";
	public static final String passwordValueError = "パスワードは半角英数字4～8文字で入力してください。";
	public static final String phoneNumValueError = "電話番号は半角数字10、あるいは11文字(ハイフンなし）で入力してください。";
	public static final String eMailValueError = "メールアドレスは半角英数字50文字以内で入力してください。";
	public static final String zipValueError = "郵便番号は半角数字7桁(ハイフンなし)で入力してください。";
	public static final String creditCardNumValueError = "クレジットカード番号は半角数字16桁で入力してください。";
	public static final String creditCardValidMonthValueError = "クレジットカード期限(月)は半角数字2桁で入力してください。";
	public static final String creditCardValidYearValueError = "クレジットカード期限(年)は半角数字4桁で入力してください。";
	public static final String creditCardSecurityCodeValueError = "クレジットカードのセキュリティコードは半角数字3桁で入力してください。";
	public static final String creditCardNameValueError = "クレジットカードの名義は半角英字(大文字、100文字以内)で入力してください。";
	public static final String passportNameValueError = "パスポート名義は半角英字(大文字、100文字以内)で入力してください。";
	public static final String passportNumValueError = "パスポート番号は半角英数字7桁で入力してください。";
}