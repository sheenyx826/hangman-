package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.PrivateSpot;

/**
 * テンプレートテーブルを管理するクラス。
 *
 * @author yokin
 */
public class PrivateSpotDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public PrivateSpotDAO(Connection con) {
		this.con = con;
	}

	/**
	 * 会員情報全件検索
	 *
	 * @return
	 * @throws SQLException
	 */

	public int insert(PrivateSpot privateSpot) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO PRIVATESPOT(PRIVATESPOT_ID, PRIVATESPOT_NAME, MEMBER_ID )" + "VALUES(?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, privateSpot.getPrivateSpotId());
			ps.setString(2, privateSpot.getPrivateSpotName());
			ps.setString(3, privateSpot.getMemberId());
			cnt = ps.executeUpdate();
		}
		return cnt;
	}


	public List<PrivateSpot> selectAll() throws SQLException {
		String sql = "SELECT * FROM PRIVATESPOT ORDER BY PRIVATESPOT_ID";
		List<PrivateSpot> list = new ArrayList<PrivateSpot>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				PrivateSpot privateSpot = new PrivateSpot();
				privateSpot.setPrivateSpotId(rs.getString("PRIVATESPOT_ID"));
				privateSpot.setPrivateSpotName(rs.getString("PRIVATESPOT_NAME"));
				privateSpot.setMemberId(rs.getString("MEMBER_ID"));

				list.add(privateSpot);
			}
		}
		return list;
	}

//	public List<Memberbp> selectById(String id) throws SQLException {
//		String sql = "SELECT *FROM MEMBERS WHERE MEMBER_ID LIKE '%'||?||'%' ";
//		List<Memberbp> list = new ArrayList<Memberbp>();
//
//		try (PreparedStatement ps = con.prepareStatement(sql)) {
//			ps.setString(1, id);
//			try (ResultSet rs = ps.executeQuery()) {
//				while (rs.next()) {
//					Memberbp memberbp = new Memberbp();
//					memberbp.setId(rs.getString("MEMBER_ID"));
//					memberbp.setName(rs.getString("MEMBER_NAME"));
//					list.add(memberbp);
//				}
//			}
//		}
//		return list;
//	}
//
//	public Memberbp confirmById(String id) throws SQLException {
//		String sql = "SELECT * FROM MEMBERS WHERE MEMBER_ID =? ";
//		Memberbp memberbp = null;
//
//		try (PreparedStatement ps = con.prepareStatement(sql)) {
//			ps.setString(1, id);
//			try (ResultSet rs = ps.executeQuery()) {
//				if (rs.next()) {
//					memberbp = new Memberbp();
//					memberbp.setId(rs.getString("MEMBER_ID"));
//					memberbp.setName(rs.getString("MEMBER_NAME"));
//
//				}
//			}
//		}
//		return memberbp;
//	}
//
//
//
//	public int update(Memberbp memberbp) throws SQLException {
//
//		int cnt = 0;
//		String sql = "UPDATE MEMBERS SET MEMBER_NAME = ? WHERE MEMBER_ID = ?";
//
//		try (PreparedStatement ps = con.prepareStatement(sql)) {
//			ps.setString(1, memberbp.getName());
//			ps.setString(2, memberbp.getId());
//			cnt = ps.executeUpdate();
//		}
//		return cnt;
//
//	}
//
//
//	public int DELETE(Memberbp memberbp) throws SQLException {
//
//		int cnt = 0;
//		String sql = "DELETE FROM  MEMBERS WHERE MEMBER_ID = ?";
//
//		try (PreparedStatement ps = con.prepareStatement(sql)) {
//			ps.setString(1, memberbp.getId());
//			cnt = ps.executeUpdate();
//		}
//		return cnt;
//
//	}

}