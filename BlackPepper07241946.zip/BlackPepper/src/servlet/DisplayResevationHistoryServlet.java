package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constants.ConstURL;
import dao.ReservationDAO;
import ds.ConnectionManager;
import bean.Reservation;

/**
 * 予約履歴一覧表示用サーブレット
 */
@WebServlet("/DisplayResevationHistoryServlet")
public class DisplayResevationHistoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ConnectionManager connectionManager = new ConnectionManager();
		List<Reservation> reservationList = new ArrayList<>();
		HttpSession session = request.getSession();
		String userId=(String) session.getAttribute("userId_tmp");

		try (
				// コネクションを取得
				Connection con = connectionManager.getConnection();) {

			// ReservationDAOのインスタンスを生成
			ReservationDAO reservationDAO = new ReservationDAO(con);

			// reservationDAOから予約情報全件取得メソッド（履歴表示）を呼び出しreservationListに入れる。
			reservationList = reservationDAO.selectReservationHistory(con,userId);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}

		// 予約履歴一覧画面(P05011)の遷移

		request.setAttribute("reservationList", reservationList);

		String url = ConstURL.DISPLAY_RESERVATION_HISTORY_PATH;

		request.getRequestDispatcher(url).forward(request, response);

	}

}
