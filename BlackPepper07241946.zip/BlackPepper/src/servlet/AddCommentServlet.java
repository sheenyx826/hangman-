package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Comment;
import constants.ConstURL;
import dao.CommentDAO;
import ds.ConnectionManager;

@WebServlet("/AddCommentServlet")
public class AddCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		String memberId = (String) session.getAttribute("userId_tmp");
		if (memberId == null) {
			request.getRequestDispatcher("/WEB-INF/P01031.jsp").forward(request, response);
			return;
		}

		String commentId = "";
		String itineraryId = request.getParameter("itineraryId");
		if (!(itineraryId == null)) {
			commentId = (memberId + itineraryId);
		}
		System.out.println(commentId);

		String spotId = request.getParameter("spotId");
		if (!(spotId == null)) {
			commentId = (memberId + spotId);
		}
		System.out.println(commentId);

		String productId = request.getParameter("productId");
		if (!(productId == null)) {
			commentId = (memberId + productId);
		}

		System.out.println(commentId);



		Comment comment = null;

		
		
		int cnt = 0;
		String url = ConstURL.DISPLAY_SPOT_DETAIL_PATH;
		/**
		 * コメント追加 メンバーＩＤ等をDAOに渡し、コメント追加
		 */




		try (Connection con = ConnectionManager.getConnection()) {

			Timestamp nowTime = new Timestamp(new Date().getTime());
			comment = new Comment();
			comment.setCommentId(commentId);
			comment.setCommentContent(request.getParameter("commentContent"));
			comment.setCommentTime(nowTime);
			comment.setMemberId(request.getParameter(memberId));
			comment.setSpotId(request.getParameter("spotId"));
			comment.setGrade(request.getParameter("grade"));
			comment.setItineraryId(request.getParameter("itineraryId"));
			comment.setProductId(request.getParameter("productId"));
			
			CommentDAO commentDAO = new CommentDAO(con);
			commentDAO.insert(con,comment);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}
		System.out.println(cnt);
		if(cnt == 1) {
			request.setAttribute("message", "コメントを投稿しました。");
		}
		request.getRequestDispatcher(url).forward(request, response);
		

	}

}
