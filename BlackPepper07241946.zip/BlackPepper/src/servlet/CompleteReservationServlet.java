package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import bean.Reservation;
import constants.ConstURL;
import constants.RankAndPoint;
import dao.MembersDAO;
import dao.ReservationDAO;
import ds.ConnectionManager;

/**
 * 予約完了画面表示用サーブレットP04012
 */
@WebServlet("/CompleteReservationServlet")
public class CompleteReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.COMPLETE_RESERVATION_PATH;

		HttpSession session = request.getSession();
		String productId = (String) session.getAttribute("productId");

		String adultCount = (String) session.getAttribute("adultCount");
		String childCount = (String) session.getAttribute("childCount");
		int inttotalAmount = Integer.parseInt(adultCount) + Integer.parseInt(childCount);
		Timestamp date = new Timestamp(new Date().getTime());
		String memberId = (String) session.getAttribute("userId_tmp");

		int cnt;
		try (Connection con = ConnectionManager.getConnection()) {

			ReservationDAO reservationDAO = new ReservationDAO(con);
			Reservation reservation = new Reservation();

			String reservationId = date + memberId;
			// Timestamp reservationTime = date;
			// **TODO reservationNumberどう持ってきたらいいのか分からない

			String departureDay = request.getParameter("departureDay");
			String totalAmount = String.valueOf(inttotalAmount);
			String paymentMethod = request.getParameter("payment");
			String creditcardNumber = request.getParameter("cardNo");
			String expiryDate = request.getParameter("expiryDate");
			String productPrice = request.getParameter("productPrice");
			String airportTax = request.getParameter("airportTax");
			String currencyUnit = request.getParameter("currencyUnit");
			String exchangeRate = request.getParameter("exchangeRate");
			String itineraryId = request.getParameter("itineraryId");
			String departureFlightId = request.getParameter("departureFlightId");
			String arrivalFlightId = request.getParameter("arrivalFlightId");

			reservation.setReservationId(reservationId);
			reservation.setProductId(productId);
			reservation.setMemberId(memberId);
			reservation.setReservationTime(date);
			// reservation.setReservationNumber(reservationNumber);
			reservation.setDepartureDay(departureDay);
			reservation.setPaymentMethod(paymentMethod);
			reservation.setCreditcardNumber(creditcardNumber);
			reservation.setExpiryDate(expiryDate);
			reservation.setProductPrice(productPrice);
			reservation.setAirportTax(airportTax);
			// reservation.setCurrenyUnit(currenyUnit);
			reservation.setExchangeRate(exchangeRate);
			reservation.setItineraryId(itineraryId);
			reservation.setDepartureFlightId(departureFlightId);
			reservation.setArrivalFlightId(arrivalFlightId);

			// reservationDAOにinsertする
			cnt = reservationDAO.insert(reservation);

			// 予約が完了したらユーザーポイントを加算する
			if (cnt == 1) {

				// メンバーIDをもとにメンバーbean生成
				Member member = new MembersDAO(con).selectByMemberId(memberId);

				RankAndPoint rankAndPoint = new RankAndPoint();

				int newUserPoint = rankAndPoint.addUserPointByReservation(member.getUserPoint());

				member.setUserPoint(newUserPoint);

			}

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}
		System.out.println(cnt);
		request.getRequestDispatcher(url).forward(request, response);

	}
}
