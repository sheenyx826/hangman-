package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Comment;

/**
 * コメントDAO
 * 
 * @author katakura
 */
public class CommentDAO {
	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */

	public CommentDAO(Connection con) {
		this.con = con;
	}

	/**
	 * コメント登録
	 */

	public int insert(Connection con,Comment comment) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO COMMENT_INF(COMMENT_ID,COMMENT_CONTENT,COMMENT_TIME,MEMBER_ID,SPOT_ID,GRADE,ITINERARY_ID,PRODUCT_ID)"
				+ "VALUES(?,?,?,?,?,?,?,?)";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, comment.getCommentId());
			ps.setString(2, comment.getCommentContent());
			ps.setTimestamp(3, comment.getCommentTime());
			ps.setString(4, comment.getMemberId());
			ps.setString(5, comment.getSpotId());
			ps.setString(6, comment.getGrade());
			ps.setString(7, comment.getItineraryId());
			ps.setString(8, comment.getProductId());

		}
		return cnt;
	}

	/**
	 * コメント表示メソッド
	 */

	public List<Comment> commentAll(String spotId) throws SQLException {
		String sql = "SELECT COMMENT_ID,COMMENT_CONTENT,COMMENT_TIME FROM COMMENT_INF WHERE SPOT_ID = ? ORDER BY COMMENT_ID";
		List<Comment> commentList = new ArrayList<Comment>();

		try (PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
) {
			 
			 ps.setString(1,spotId);
			
			while (rs.next()) {
				Comment comment = new Comment();
				
				comment.setCommentId(rs.getString("COMMENT_ID"));
				comment.setCommentContent(rs.getString("COMMENT_CONTENT"));
				comment.setCommentTime(rs.getTimestamp("COMMENT_TIME"));
				comment.setMemberId(rs.getString("MEMBER_ID"));
				comment.setSpotId(rs.getString("SPOT_ID"));
				comment.setGrade(rs.getString("grade"));
				comment.setItineraryId(rs.getString("ITINERARY_ID"));
				comment.setProductId(rs.getString("PRODUCT_ID"));

				commentList.add(comment);
			}
		}
		return commentList;
	}

}
