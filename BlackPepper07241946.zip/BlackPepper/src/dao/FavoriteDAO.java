package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Favorite;

/**
 * 
 * 
 * 
 * @author SUZUKI
 *
 *
 */
public class FavoriteDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public FavoriteDAO(Connection con) {
		this.con = con;
	}

	public int insert(String favoriteId, String itineraryId, String spotId, String productId, String memberId)
			throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO FAVORITE VALUES(?,?,?,?,?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, favoriteId);
			ps.setString(2, itineraryId);
			ps.setString(3, spotId);
			ps.setString(4, productId);
			ps.setString(5, memberId);
			cnt = ps.executeUpdate();
		}
		return cnt;
	}

	public ArrayList<Favorite> selectAll(String inputId) throws SQLException {
		String sql = "SELECT FAVO.* ,PRO.PRODUCT_NAME FROM (SELECT * FROM FAVORITE WHERE PRODUCT_ID IS NOT NULL AND MEMBER_ID=?) FAVO JOIN (SELECT PRODUCT_NAME,PRODUCT_ID FROM PRODUCT) PRO ON FAVO.PRODUCT_ID=PRO.PRODUCT_ID";

		ArrayList<Favorite> favoriteList = new ArrayList<Favorite>();

		try (PreparedStatement ps = con.prepareStatement(sql);) {

			ps.setString(1, inputId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Favorite newfavorite = new Favorite();

				newfavorite.setFavoriteId(rs.getString("FAVORITE_ID"));
				newfavorite.setProductId(rs.getString("PRODUCT_ID"));
				newfavorite.setMemberId(rs.getString("MEMBER_ID"));
				newfavorite.setProductName(rs.getString("PRODUCT_NAME"));

				favoriteList.add(newfavorite);

			}
		}
		return favoriteList;
	}

	/**
	 * 
	 * ユーザーIDに紐づくお気に入りスポットを検索し、リストで返す
	 * 
	 * 
	 * @param inputId
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<Favorite> selectSpotAll(String inputId) throws SQLException {
		String sql = "SELECT FAVO.* ,PRO.SPOT_NAME FROM (SELECT * FROM FAVORITE WHERE SPOT_ID IS NOT NULL AND MEMBER_ID=?) FAVO JOIN (SELECT SPOT_NAME,SPOT_ID FROM SPOT) PRO ON FAVO.SPOT_ID=PRO.SPOT_ID";

		ArrayList<Favorite> favoriteList = new ArrayList<Favorite>();

		try (PreparedStatement ps = con.prepareStatement(sql);) {

			ps.setString(1, inputId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Favorite newfavorite = new Favorite();

				newfavorite.setFavoriteId(rs.getString("FAVORITE_ID"));
				newfavorite.setSpotId(rs.getString("SPOT_ID"));
				newfavorite.setMemberId(rs.getString("MEMBER_ID"));
				newfavorite.setSpotName(rs.getString("SPOT_NAME"));

				favoriteList.add(newfavorite);

			}
		}
		return favoriteList;
	}

	public ArrayList<Favorite> selectFreeTourAll(String inputId) throws SQLException {
		String sql = "SELECT FAVO.* ,PRO.ITINERARY_NAME FROM (SELECT * FROM FAVORITE WHERE ITINERARY_ID IS NOT NULL AND MEMBER_ID=?) FAVO JOIN (SELECT ITINERARY_NAME,ITINERARY_ID FROM ITINERARY) PRO ON FAVO.ITINERARY_ID=PRO.ITINERARY_ID";

		ArrayList<Favorite> favoriteList = new ArrayList<Favorite>();

		try (PreparedStatement ps = con.prepareStatement(sql);) {

			ps.setString(1, inputId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Favorite newfavorite = new Favorite();

				newfavorite.setFavoriteId(rs.getString("FAVORITE_ID"));
				newfavorite.setSpotId(rs.getString("ITINERARY_ID"));
				newfavorite.setMemberId(rs.getString("MEMBER_ID"));
				newfavorite.setSpotName(rs.getString("ITINERARY_NAME"));

				favoriteList.add(newfavorite);

			}
		}
		return favoriteList;
	}

}
