package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Product;
import bean.Reservation;

/**
 * テンプレートテーブルを管理するクラス。
 *
 * @author
 */
public class ReservationDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public ReservationDAO(Connection con) {
		this.con = con;
	}

	/** 予約情報追加メソッド */
	public int insert(Reservation reservation) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO RESERVATION(RESERVATION_ID, PRODUCT_ID,MEMBER_ID,RESERVATION_TIME,RESERVATION_NUMBER,DEPARTURE_DAY,TOTAL_AMOUNT,PAYMENT_METHOD,CREDITCARD_NUMBER,EXPIRY_DATE,PRODUCT_PRICE,AIRPORT_TAX,CURRENCY_UNIT,EXCHANGE_RATE,ITINERARY_ID,DEPARTURE_FLIGHT_ID,ARRIVAL_FLIGHT_ID)"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, reservation.getReservationId());
			ps.setString(2, reservation.getProductId());
			ps.setString(3, reservation.getMemberId());
			ps.setTimestamp(4, reservation.getReservationTime());
			ps.setString(5, reservation.getReservationNumber());
			ps.setString(6, reservation.getDepartureDay());
			ps.setString(7, reservation.getTotalAmount());
			ps.setString(8, reservation.getPaymentMethod());
			ps.setString(9, reservation.getCreditcardNumber());
			ps.setString(10, reservation.getExpiryDate());
			ps.setString(11, reservation.getProductPrice());
			ps.setString(12, reservation.getAirportTax());
			ps.setString(13, reservation.getCurrencyUnit());
			ps.setString(14, reservation.getExchangeRate());
			ps.setString(15, reservation.getItineraryId());
			ps.setString(16, reservation.getDepartureFlightId());
			ps.setString(17, reservation.getArrivalFlightId());
			cnt = ps.executeUpdate();
		}
		return cnt;
	}

	/** 予約情報単一取得メソッド */
	public Reservation selectById(Connection con, String reservation_id) throws SQLException {
		Reservation reservation = null;
		String sql = "";

		try (PreparedStatement ps = con.prepareStatement(sql)) {

		}

		return reservation;
	}

	/** 予約情報削除メソッド */
	public int delete(String reservationId) throws SQLException {

		int cnt = 0;
		String sql = "DELETE FROM RESERVATION WHERE RESERVATION_ID = ?";

		Reservation reservation = new Reservation();
		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, reservation.getReservationId());
			cnt = ps.executeUpdate();
		}
		return cnt;

	}

	/** 予約情報全件取得（履歴表示）メソッド */
	public List<Reservation> selectReservationHistory(Connection con, String userId) throws SQLException {

		// 引数ConnectionからPreparedStatementを取得
		// Listの生成
		List<Reservation> reservationList = new ArrayList<>();

		try (PreparedStatement ps = con
				.prepareStatement("SELECT * FROM RESERVATION WHERE MEMBER_ID = ? ORDER BY DEPARTURE_DAY DESC");) {

			ps.setString(1, userId);

			// SQLの実行
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Reservation reservation = new Reservation();
				reservation.setReservationId(rs.getString("RESERVATION_ID"));
				reservation.setProductId(rs.getString("PRODUCT_ID"));
				reservation.setDepartureDay(rs.getString("DEPARTURE_DAY"));
				reservation.setTotalAmount(rs.getString("TOTAL_AMOUNT"));
				reservationList.add(reservation);
			}
		}

		return reservationList;
	}

	/** 予約詳細情報メソッド */
	public Reservation selectReservationHistoryDetail(Connection con, String userId, String productId)
			throws SQLException {

		// 引数ConnectionからPreparedStatementを取得
		// Listの生成
		Reservation reservationId = new Reservation();

		try (PreparedStatement ps = con
				.prepareStatement("SELECT RESERVATION_ID FROM RESERVATION WHERE MEMBER_ID = ? AND PRODUCT_ID = ?");) {

			ps.setString(1, userId);
			ps.setString(2, productId);

			// SQLの実行
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				reservationId.setReservationId(rs.getString("RESERVATION_ID"));
			}
		}

		return reservationId;
	}

}
