package constants;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValueCheck {
	/**
	 * 入力値確認
	 * 
	 * @param param
	 *            フォームから入力された値
	 * @param regex
	 *            チェックする正規表現
	 * @return boolean 書式に適しているか否か
	 */
	public static boolean isSuitableFormat(String param, String regex) {
		Pattern patternNum = Pattern.compile(regex);
		Matcher patternNumMatcher = patternNum.matcher(param);

		return patternNumMatcher.matches();
	}

	/**
	 * Nullチェック
	 * 
	 * @param param
	 *            フォームから入力された値
	 * @return boolean null/空文字か否か
	 */
	public static boolean isEmpty(String param) {
		return (param == null || param.isEmpty());
	}

	/**
	 * 配列Nullチェック
	 * 
	 * @param param
	 *            フォームから入力された配列
	 * @return boolean null/空か否か
	 */
	public static boolean isValuesEmpty(String[] param) {
		return (param == null || param.length == 0);
	}
}
