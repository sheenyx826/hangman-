package constants;

public class RankAndPoint {
	/**
	 * ランクとポイントのクラス
	 * 
	 *
	 */
	public static String userRank(int userPoint) {
		String rank;
		if (userPoint > 300) {
			rank = "GOD";
		} else if (userPoint > 200) {
			rank = "PLATINUM";
		} else if (userPoint > 100) {
			rank = "GOLD";
		} else if (userPoint > 50) {
			rank = "SILVER";
		} else if (userPoint > 30) {
			rank = "BRONZE";
		} else {
			rank = "ザコ";
		}
		return rank;
	}

	public static int toNextRank(int userPoint) {
		int necessaryPoint;
		if (userPoint >= 300) {
			necessaryPoint = 0;
		} else if (userPoint >= 200) {
			necessaryPoint = 300 - userPoint;
		} else if (userPoint >= 100) {
			necessaryPoint = 200 - userPoint;
		} else if (userPoint >= 50) {
			necessaryPoint = 100 - userPoint;
		} else if (userPoint >= 30) {
			necessaryPoint = 50 - userPoint;
		} else {
			necessaryPoint = 30 - userPoint;
		}
		return necessaryPoint;
	}

	public int addUserPointByReservation(int userPoint) {
		userPoint += 30;
		return userPoint;
	}

	public static int addUserPointByFavoriteTrip(int userPoint) {
		userPoint += 20;
		return userPoint;
	}

	public static int addUserPointByFavoriteSpot(int userPoint) {
		userPoint += 10;
		return userPoint;
	}
}
