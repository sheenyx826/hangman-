package bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class Itinerary implements Serializable {
	/**
	 *
	 */

	private static final long serialVersionUID = 1L;




	private String itineraryId;
	private String memberId;
	private String itineraryName;
	private Timestamp createTime;
	private String itineraryOverview;
	private String countryId;
	private String countryName;
	public String getItineraryId() {
		return itineraryId;
	}
	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getItineraryName() {
		return itineraryName;
	}
	public void setItineraryName(String itineraryName) {
		this.itineraryName = itineraryName;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public String getItineraryOverview() {
		return itineraryOverview;
	}
	public void setItineraryOverview(String itineraryOverview) {
		this.itineraryOverview = itineraryOverview;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	@Override
	public String toString() {
		return "Itinerary [itineraryId=" + itineraryId + ", memberId=" + memberId + ", itineraryName=" + itineraryName
				+ ", createTime=" + createTime + ", itineraryOverview=" + itineraryOverview + ", countryId=" + countryId
				+ ", countryName=" + countryName + "]";
	}




}
