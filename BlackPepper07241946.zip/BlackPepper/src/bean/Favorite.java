package bean;

/**
 * 
 * @author SUZUKI
 *
 */
public class Favorite {

	private static final long serialVersionUID = 1L;
	private String favoriteId;
	private String itineraryId;
	private String spotId;
	private String productId;
	private String memberId;

	private String itineraryName;
	private String spotName;
	private String productName;
	private String memberName;

	public Favorite() {
	}

	public String getFavoriteId() {
		return favoriteId;
	}

	public void setFavoriteId(String favoriteId) {
		this.favoriteId = favoriteId;
	}

	public String getItineraryId() {
		return itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	public String getSpotId() {
		return spotId;
	}

	public void setSpotId(String spotId) {
		this.spotId = spotId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((favoriteId == null) ? 0 : favoriteId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Favorite other = (Favorite) obj;
		if (favoriteId == null) {
			if (other.favoriteId != null)
				return false;
		} else if (!favoriteId.equals(other.favoriteId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Favorite [favoriteId=" + favoriteId + ", itineraryId=" + itineraryId + ", spotId=" + spotId
				+ ", productId=" + productId + ", memberId=" + memberId + "]";
	}

	public String getItineraryName() {
		return itineraryName;
	}

	public void setItineraryName(String itineraryName) {
		this.itineraryName = itineraryName;
	}

	public String getSpotName() {
		return spotName;
	}

	public void setSpotName(String spotName) {
		this.spotName = spotName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

}
