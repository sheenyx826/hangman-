(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.tabs').tabs();
    $('.dropdown-trigger').dropdown();
    $('.modal').modal();
    $('textarea#textarea').characterCounter();
    $('select').formSelect();
    $('.slider').slider();
    $('.datepicker').datepicker({
				i18n : {
					selectMonths : true, // Creates a
					// dropdown to
					// control
					// month
					yearRange : 15, // Creates a dropdown of 15
					// years to
					// control year
					months : [ "1月", "2月", "3月", "4月", "5月",
							"6月", "7月", "8月", "9月", "10月",
							"11月", "12月" ],
					monthsShort : [ "1/", "2/", "3/", "4/",
							"5/", "6/", "7/", "8/", "9/",
							"10/", "11/", "12/" ],
					weekdays : [ "日曜日", "月曜日", "火曜日", "水曜日",
							"木曜日", "金曜日", "土曜日" ],
					weekdaysShort : [ "日", "月", "火", "水", "木",
							"金", "土" ],
					weekdaysAbbrev : [ "日", "月", "火", "水", "木",
							"金", "土" ],
					nextMonth : "翌月",
					previousMonth : "前月",
					today : "今日",
					clear : "クリア",
					cancel : "閉じる",
					done : "OK"
				},
				format : "yyyy/mm/dd"
			});
    $('.timepicker').timepicker(
    		{
    			twelveHour : false
    		});

  }); // end of document ready
})(jQuery); // end of jQuery name space