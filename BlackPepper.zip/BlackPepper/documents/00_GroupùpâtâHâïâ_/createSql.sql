
/* Drop Tables */

DROP TABLE comment_inf CASCADE CONSTRAINTS;
DROP TABLE favorite CASCADE CONSTRAINTS;
DROP TABLE picture CASCADE CONSTRAINTS;
DROP TABLE spotinf CASCADE CONSTRAINTS;
DROP TABLE spot CASCADE CONSTRAINTS;
DROP TABLE category CASCADE CONSTRAINTS;
DROP TABLE reservation CASCADE CONSTRAINTS;
DROP TABLE flight_inf CASCADE CONSTRAINTS;
DROP TABLE city CASCADE CONSTRAINTS;
DROP TABLE itinerary CASCADE CONSTRAINTS;
DROP TABLE country CASCADE CONSTRAINTS;
DROP TABLE members CASCADE CONSTRAINTS;
DROP TABLE optional_tour CASCADE CONSTRAINTS;
DROP TABLE product CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE category
(
	category_id number(2) NOT NULL,
	category_name nvarchar2(100),
	PRIMARY KEY (category_id)
);


CREATE TABLE city
(
	city_id number(5) NOT NULL,
	city_name nvarchar2(100),
	country_id number(3) NOT NULL,
	country_name nvarchar2(100),
	PRIMARY KEY (city_id)
);


CREATE TABLE comment_inf
(
	comment_id nvarchar2(20) NOT NULL,
	comment_content nvarchar2(1000),
	comment_time timestamp,
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	spot_id nvarchar2(20),
	-- 1-5点とする
	grade number NOT NULL,
	itinerary_id nvarchar2(20),
	product_id nvarchar2(20),
	PRIMARY KEY (comment_id)
);


CREATE TABLE country
(
	country_id number(3) NOT NULL,
	country_name nvarchar2(100),
	PRIMARY KEY (country_id)
);


CREATE TABLE favorite
(
	favorite_id nvarchar2(20) NOT NULL,
	itinerary_id nvarchar2(20),
	spot_id nvarchar2(20),
	product_id nvarchar2(20),
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	PRIMARY KEY (favorite_id)
);


CREATE TABLE flight_inf
(
	flight_id nvarchar2(20) NOT NULL,
	arrival_time timestamp,
	departure_time timestamp,
	departure_city_id number(5),
	arrival_city_id number(5),
	departure_city_name nvarchar2(100),
	arrival_city_name nvarchar2(100),
	airport_tax number(10),
	currency_unit nvarchar2(10),
	PRIMARY KEY (flight_id)
);


CREATE TABLE itinerary
(
	itinerary_id nvarchar2(20) NOT NULL,
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	itinerary_name nvarchar2(100),
	create_time timestamp,
	itinerary_overview nvarchar2(1000),
	country_id number(3),
	country_name nvarchar2(100),
	PRIMARY KEY (itinerary_id)
);


CREATE TABLE members
(
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	member_name nvarchar2(100),
	member_point number(10) DEFAULT 0,
	member_password nvarchar2(100) NOT NULL,
	member_address nvarchar2(1000),
	member_postcode nvarchar2(7),
	member_phone nvarchar2(20),
	creditcard_month nvarchar2(2),
	creditcard_year nvarchar2(4),
	creditcard_name nvarchar2(100),
	creditcard_number nvarchar2(16),
	creditcard_code nvarchar2(3),
	passport_name nvarchar2(100),
	passport_number nvarchar2(50),
	PRIMARY KEY (member_id)
);


CREATE TABLE optional_tour
(
	tour_id nvarchar2(20) NOT NULL,
	tour_name nvarchar2(100),
	tour_content nvarchar2(1000),
	tour_price number(10),
	PRIMARY KEY (tour_id)
);


CREATE TABLE picture
(
	picture_id nvarchar2(50) NOT NULL,
	picture_name nvarchar2(100),
	picture_link nvarchar2(1000),
	spot_id nvarchar2(20),
	product_id nvarchar2(20),
	tour_id nvarchar2(20),
	itinerary_id nvarchar2(20),
	PRIMARY KEY (picture_id)
);


CREATE TABLE product
(
	product_id nvarchar2(20) NOT NULL,
	product_name nvarchar2(100) NOT NULL,
	product_content nvarchar2(1000),
	product_price number(10) NOT NULL,
	airport_tax number(10),
	currency_unit nvarchar2(10),
	exchange_rate number(8,3),
	minimum_number number(5),
	stock_quantity number(5),
	remarks nvarchar2(1000),
	update_time timestamp,
	departure_time timestamp,
	arrival_time timestamp,
	PRIMARY KEY (product_id)
);


CREATE TABLE reservation
(
	reservation_id nvarchar2(20) NOT NULL,
	product_id nvarchar2(20),
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	reservation_time timestamp,
	reservation_number number(5),
	departure_day date,
	total_amount number(10),
	-- 1:クレジット
	-- 2:銀行振込
	payment_method number,
	creditcard_number nvarchar2(16),
	expiry_date nvarchar2(4),
	product_price number(10),
	airport_tax number(10),
	currency_unit nvarchar2(10),
	exchange_rate number(8,3),
	itinerary_id nvarchar2(20),
	departure_flight_id nvarchar2(20),
	arrival_flight_id nvarchar2(20),
	PRIMARY KEY (reservation_id)
);


CREATE TABLE spot
(
	spot_id nvarchar2(20) NOT NULL,
	spot_name nvarchar2(100) NOT NULL,
	-- メアド
	member_id nvarchar2(100),
	city_id number(5),
	tour1_id nvarchar2(20),
	tour2_id nvarchar2(20),
	tour3_id nvarchar2(20),
	spot_content nvarchar2(1000),
	category1_id number(2),
	category2_id number(2),
	category3_id number(2),
	category4_id number(2),
	category5_id number(2),
	category6_id number(2),
	country_name nvarchar2(100),
	PRIMARY KEY (spot_id)
);


CREATE TABLE spotinf
(
	spot_infid nvarchar2(20) NOT NULL,
	-- 1-9
	daynumber number NOT NULL,
	itinerary_id nvarchar2(20) NOT NULL,
	-- 朝1　午後2　夜3
	timestate number NOT NULL,
	-- 1-3
	sequenceinf number NOT NULL,
	spot_id nvarchar2(20) NOT NULL,
	tour_content nvarchar2(1000),
	tour_name nvarchar2(100),
	tour_price number(10),
	PRIMARY KEY (spot_infid)
);



/* Create Foreign Keys */

ALTER TABLE spot
	ADD FOREIGN KEY (category3_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category1_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category6_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category4_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category2_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category5_id)
	REFERENCES category (category_id)
;


ALTER TABLE flight_inf
	ADD FOREIGN KEY (departure_city_id)
	REFERENCES city (city_id)
;


ALTER TABLE flight_inf
	ADD FOREIGN KEY (arrival_city_id)
	REFERENCES city (city_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (city_id)
	REFERENCES city (city_id)
;


ALTER TABLE city
	ADD FOREIGN KEY (country_id)
	REFERENCES country (country_id)
;


ALTER TABLE itinerary
	ADD FOREIGN KEY (country_id)
	REFERENCES country (country_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (arrival_flight_id)
	REFERENCES flight_inf (flight_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (departure_flight_id)
	REFERENCES flight_inf (flight_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE spotinf
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE itinerary
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (tour_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour2_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour1_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour3_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE spotinf
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;



/* Comments */

COMMENT ON COLUMN comment_inf.member_id IS 'メアド';
COMMENT ON COLUMN comment_inf.grade IS '1-5点とする';
COMMENT ON COLUMN favorite.member_id IS 'メアド';
COMMENT ON COLUMN itinerary.member_id IS 'メアド';
COMMENT ON COLUMN members.member_id IS 'メアド';
COMMENT ON COLUMN reservation.member_id IS 'メアド';
COMMENT ON COLUMN reservation.payment_method IS '1:クレジット
2:銀行振込';
COMMENT ON COLUMN spot.member_id IS 'メアド';
COMMENT ON COLUMN spotinf.daynumber IS '1-9';
COMMENT ON COLUMN spotinf.timestate IS '朝1　午後2　夜3';
COMMENT ON COLUMN spotinf.sequenceinf IS '1-3';

-- カテゴリ
INSERT INTO category (category_id, category_name) VALUES ('1', 'オプショナルツアー付きオプショナルツアー付き');
INSERT INTO category (category_id, category_name) VALUES ('2', 'ユーザー作成');
INSERT INTO category (category_id, category_name) VALUES ('3', '文化');
INSERT INTO category (category_id, category_name) VALUES ('4', 'グルメ');
INSERT INTO category (category_id, category_name) VALUES ('5', '風景');
INSERT INTO category (category_id, category_name) VALUES ('6', '遺産');


-- 国
INSERT INTO country (country_id, country_name) VALUES ('1', '日本');
INSERT INTO country (country_id, country_name) VALUES ('2', 'インド');


-- 都市
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('1', '東京', '1', '');
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('2', '大阪', '1', '');
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('3', 'デリー', '2', '');





-- 会員
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('1', '加藤', '0', '1', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('2', '片倉', '0', '2', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('3', '叶', '0', '3', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('4', '鈴木', '0', '4', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('5', '倉田', '0', '5', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('6', '松村', '0', '6', '', '', '', '', '', '', '', '', '', '');


-- オプショナルツアー
INSERT INTO optional_tour (tour_id, tour_name, tour_content, tour_price) VALUES ('1', '3時間ガイド', '', '10000');
INSERT INTO optional_tour (tour_id, tour_name, tour_content, tour_price) VALUES ('2', '5時間ガイド', '', '20000');




-- スポット
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('1', '東京タワー', '3', '1', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('2', '東京カレー', '1', '1', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('3', '東京駅', '2', '1', '', '', '', '', '', '', '', '', '', '', '');



-- 旅程表
INSERT INTO itinerary (itinerary_id, member_id, itinerary_name, create_time, itinerary_overview, country_id, country_name) VALUES ('1', '1', '', '', '', '1', '');



-- 旅程表項目
INSERT INTO spotinf (spot_infid, daynumber, itinerary_id, timestate, sequenceinf, spot_id, tour_content, tour_name, tour_price) VALUES ('1', '1', '1', '1', '1', '1', '', '', '');
INSERT INTO spotinf (spot_infid, daynumber, itinerary_id, timestate, sequenceinf, spot_id, tour_content, tour_name, tour_price) VALUES ('2', '1', '1', '2', '3', '2', '', '', '');


-- 商品
INSERT INTO product (product_id, product_name, product_content, product_price, airport_tax, currency_unit, exchange_rate, minimum_number, stock_quantity, remarks, update_time, departure_time, arrival_time) VALUES ('1', '東京体験三日間', '', '10000', '', '', '', '', '', '', '', '', '');
INSERT INTO product (product_id, product_name, product_content, product_price, airport_tax, currency_unit, exchange_rate, minimum_number, stock_quantity, remarks, update_time, departure_time, arrival_time) VALUES ('2', 'インド文化五日間体験', '', '200000', '', '', '', '', '', '', '', '', '');


-- 予約
INSERT INTO reservation (reservation_id, product_id, member_id, reservation_time, reservation_number, departure_day, total_amount, payment_method, creditcard_number, expiry_date, product_price, airport_tax, currency_unit, exchange_rate, itinerary_id, departure_flight_id, arrival_flight_id) VALUES ('1', '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO reservation (reservation_id, product_id, member_id, reservation_time, reservation_number, departure_day, total_amount, payment_method, creditcard_number, expiry_date, product_price, airport_tax, currency_unit, exchange_rate, itinerary_id, departure_flight_id, arrival_flight_id) VALUES ('2', '2', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '');



-- お気に入り
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('1', '', '1', '', '1');
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('2', '', '3', '', '4');
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('3', '', '', '1', '3');




