-- カテゴリ
INSERT INTO category (category_id, category_name) VALUES ('1', 'オプショナルツアー付きオプショナルツアー付き');
INSERT INTO category (category_id, category_name) VALUES ('2', 'ユーザー作成');
INSERT INTO category (category_id, category_name) VALUES ('3', '文化');
INSERT INTO category (category_id, category_name) VALUES ('4', 'グルメ');
INSERT INTO category (category_id, category_name) VALUES ('5', '風景');
INSERT INTO category (category_id, category_name) VALUES ('6', '遺産');


-- 国
INSERT INTO country (country_id, country_name) VALUES ('1', '日本');
INSERT INTO country (country_id, country_name) VALUES ('2', 'インド');


-- 都市
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('1', '東京', '1', '');
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('2', '大阪', '1', '');
INSERT INTO city (city_id, city_name, country_id, country_name) VALUES ('3', 'デリー', '2', '');





-- 会員
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('1', '加藤', '0', '1', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('2', '片倉', '0', '2', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('3', '叶', '0', '3', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('4', '鈴木', '0', '4', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('5', '倉田', '0', '5', '', '', '', '', '', '', '', '', '', '');
INSERT INTO members (member_id, member_name, member_point, member_password, member_address, member_postcode, member_phone, creditcard_month, creditcard_year, creditcard_name, creditcard_number, creditcard_code, passport_name, passport_number) VALUES ('6', '松村', '0', '6', '', '', '', '', '', '', '', '', '', '');


-- オプショナルツアー
INSERT INTO optional_tour (tour_id, tour_name, tour_content, tour_price) VALUES ('1', '3時間ガイド', '', '10000');
INSERT INTO optional_tour (tour_id, tour_name, tour_content, tour_price) VALUES ('2', '5時間ガイド', '', '20000');




-- スポット
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('1', '東京タワー', '3', '1', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('2', '東京カレー', '1', '1', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO spot (spot_id, spot_name, member_id, city_id, tour1_id, tour2_id, tour3_id, spot_content, category1_id, category2_id, category3_id, category4_id, category5_id, category6_id, country_name) VALUES ('3', '東京駅', '2', '1', '', '', '', '', '', '', '', '', '', '', '');



-- 旅程表
INSERT INTO itinerary (itinerary_id, member_id, itinerary_name, create_time, itinerary_overview, country_id, country_name) VALUES ('1', '1', '', '', '', '1', '');



-- 旅程表項目
INSERT INTO spotinf (spot_infid, daynumber, itinerary_id, timestate, sequenceinf, spot_id, tour_content, tour_name, tour_price) VALUES ('1', '1', '1', '1', '1', '1', '', '', '');
INSERT INTO spotinf (spot_infid, daynumber, itinerary_id, timestate, sequenceinf, spot_id, tour_content, tour_name, tour_price) VALUES ('2', '1', '1', '2', '3', '2', '', '', '');


-- 商品
INSERT INTO product (product_id, product_name, product_content, product_price, airport_tax, currency_unit, exchange_rate, minimum_number, stock_quantity, remarks, update_time, departure_time, arrival_time) VALUES ('1', '東京体験三日間', '', '10000', '', '', '', '', '', '', '', '', '');
INSERT INTO product (product_id, product_name, product_content, product_price, airport_tax, currency_unit, exchange_rate, minimum_number, stock_quantity, remarks, update_time, departure_time, arrival_time) VALUES ('2', 'インド文化五日間体験', '', '200000', '', '', '', '', '', '', '', '', '');


-- 予約
INSERT INTO reservation (reservation_id, product_id, member_id, reservation_time, reservation_number, departure_day, total_amount, payment_method, creditcard_number, expiry_date, product_price, airport_tax, currency_unit, exchange_rate, itinerary_id, departure_flight_id, arrival_flight_id) VALUES ('1', '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO reservation (reservation_id, product_id, member_id, reservation_time, reservation_number, departure_day, total_amount, payment_method, creditcard_number, expiry_date, product_price, airport_tax, currency_unit, exchange_rate, itinerary_id, departure_flight_id, arrival_flight_id) VALUES ('2', '2', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '');



-- お気に入り
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('1', '', '1', '', '1');
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('2', '', '3', '', '4');
INSERT INTO favorite (favorite_id, itinerary_id, spot_id, product_id, member_id) VALUES ('3', '', '', '1', '3');


