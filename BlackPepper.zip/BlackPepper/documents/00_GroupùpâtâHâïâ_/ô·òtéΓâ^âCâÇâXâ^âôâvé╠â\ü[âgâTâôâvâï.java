package test;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class 日付やタイムスタンプのソートサンプル {

	public static void main(String[] args) {
		// Timestamp型のソート
		System.out.println("Timestamp型のソート-------------");
		Timestamp t1 = new Timestamp(10000);
		Timestamp t2 = new Timestamp(20000);
		Timestamp t3 = new Timestamp(30000);
		Timestamp t4 = new Timestamp(40000);
		List<Timestamp> arrayList = new ArrayList<Timestamp>();
		arrayList.add(t4);
		arrayList.add(t1);
		arrayList.add(t3);
		arrayList.add(t2);
		arrayList.sort((x,y)  -> x.compareTo(y));
		for (Timestamp timestamp : arrayList) {
			System.out.println(timestamp);
		}

		System.out.println("Date型のソート-------------");
		// Date型のソート
		Date a1 = new Date(1000);
		Date a2 = new Date(2000);
		Date a3 = new Date(3000);
		Date a4 = new Date(4000);
		List<Date> aaa = new ArrayList<Date>();
		aaa.add(a4);
		aaa.add(a1);
		aaa.add(a3);
		aaa.add(a2);

		aaa.sort((x, y) -> x.compareTo(y));

		// sort結果を確認
		for (Date date : aaa) {
			System.out.println(date);
		}
	}

}
