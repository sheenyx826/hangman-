
/* Drop Tables */

DROP TABLE comment_inf CASCADE CONSTRAINTS;
DROP TABLE favorite CASCADE CONSTRAINTS;
DROP TABLE picture CASCADE CONSTRAINTS;
DROP TABLE spotinf CASCADE CONSTRAINTS;
DROP TABLE spot CASCADE CONSTRAINTS;
DROP TABLE category CASCADE CONSTRAINTS;
DROP TABLE reservation CASCADE CONSTRAINTS;
DROP TABLE flight_inf CASCADE CONSTRAINTS;
DROP TABLE city CASCADE CONSTRAINTS;
DROP TABLE itinerary CASCADE CONSTRAINTS;
DROP TABLE country CASCADE CONSTRAINTS;
DROP TABLE members CASCADE CONSTRAINTS;
DROP TABLE optional_tour CASCADE CONSTRAINTS;
DROP TABLE product CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE category
(
	category_id number(2) NOT NULL,
	category_name nvarchar2(100),
	PRIMARY KEY (category_id)
);


CREATE TABLE city
(
	city_id number(5) NOT NULL,
	city_name nvarchar2(100),
	country_id number(3) NOT NULL,
	country_name nvarchar2(100),
	PRIMARY KEY (city_id)
);


CREATE TABLE comment_inf
(
	comment_id nvarchar2(100) NOT NULL,
	comment_content nvarchar2(1000),
	comment_time timestamp,
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	spot_id nvarchar2(100),
	-- 1-5点とする
	grade number NOT NULL,
	itinerary_id nvarchar2(100),
	product_id nvarchar2(100),
	PRIMARY KEY (comment_id)
);


CREATE TABLE country
(
	country_id number(3) NOT NULL,
	country_name nvarchar2(100),
	PRIMARY KEY (country_id)
);


CREATE TABLE favorite
(
	favorite_id nvarchar2(100) NOT NULL,
	itinerary_id nvarchar2(100),
	spot_id nvarchar2(100),
	product_id nvarchar2(100),
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	PRIMARY KEY (favorite_id)
);


CREATE TABLE flight_inf
(
	flight_id nvarchar2(100) NOT NULL,
	arrival_time timestamp,
	departure_time timestamp,
	departure_city_id number(5),
	arrival_city_id number(5),
	departure_city_name nvarchar2(100),
	arrival_city_name nvarchar2(100),
	airport_tax number(10),
	currency_unit nvarchar2(10),
	PRIMARY KEY (flight_id)
);


CREATE TABLE itinerary
(
	itinerary_id nvarchar2(100) NOT NULL,
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	itinerary_name nvarchar2(100),
	create_time timestamp,
	itinerary_overview nvarchar2(1000),
	country_id number(3),
	country_name nvarchar2(100),
	PRIMARY KEY (itinerary_id)
);


CREATE TABLE members
(
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	member_name nvarchar2(100),
	member_point number(10) DEFAULT 0,
	member_password nvarchar2(100) NOT NULL,
	member_address nvarchar2(1000),
	member_postcode nvarchar2(7),
	member_phone nvarchar2(20),
	creditcard_month nvarchar2(2),
	creditcard_year nvarchar2(4),
	creditcard_name nvarchar2(100),
	creditcard_number nvarchar2(16),
	creditcard_code nvarchar2(3),
	passport_name nvarchar2(100),
	passport_number nvarchar2(50),
	PRIMARY KEY (member_id)
);


CREATE TABLE optional_tour
(
	tour_id nvarchar2(100) NOT NULL,
	tour_name nvarchar2(100),
	tour_content nvarchar2(1000),
	tour_price number(10),
	PRIMARY KEY (tour_id)
);


CREATE TABLE picture
(
	picture_id nvarchar2(100) NOT NULL,
	picture_name nvarchar2(100),
	picture_link nvarchar2(1000),
	spot_id nvarchar2(100),
	product_id nvarchar2(100),
	tour_id nvarchar2(100),
	itinerary_id nvarchar2(100),
	PRIMARY KEY (picture_id)
);


CREATE TABLE product
(
	product_id nvarchar2(100) NOT NULL,
	product_name nvarchar2(100) NOT NULL,
	product_content nvarchar2(1000),
	product_price number(10) NOT NULL,
	airport_tax number(10),
	currency_unit nvarchar2(10),
	exchange_rate number(8,3),
	minimum_number number(5),
	stock_quantity number(5),
	remarks nvarchar2(1000),
	update_time timestamp,
	departure_time timestamp,
	arrival_time timestamp,
	PRIMARY KEY (product_id)
);


CREATE TABLE reservation
(
	reservation_id nvarchar2(100) NOT NULL,
	product_id nvarchar2(100),
	-- メアド
	member_id nvarchar2(100) NOT NULL,
	reservation_time timestamp,
	reservation_number number(5),
	departure_day date,
	total_amount number(10),
	-- 1:クレジット
	-- 2:銀行振込
	payment_method number,
	creditcard_number nvarchar2(16),
	expiry_date nvarchar2(4),
	product_price number(10),
	airport_tax number(10),
	currency_unit nvarchar2(10),
	exchange_rate number(8,3),
	itinerary_id nvarchar2(100),
	departure_flight_id nvarchar2(100),
	arrival_flight_id nvarchar2(100),
	PRIMARY KEY (reservation_id)
);


CREATE TABLE spot
(
	spot_id nvarchar2(100) NOT NULL,
	spot_name nvarchar2(100) NOT NULL,
	-- メアド
	member_id nvarchar2(100),
	city_id number(5),
	tour1_id nvarchar2(100),
	tour2_id nvarchar2(100),
	tour3_id nvarchar2(100),
	spot_content nvarchar2(1000),
	category1_id number(2),
	category2_id number(2),
	category3_id number(2),
	category4_id number(2),
	category5_id number(2),
	category6_id number(2),
	country_name nvarchar2(100),
	PRIMARY KEY (spot_id)
);


CREATE TABLE spotinf
(
	spot_infid nvarchar2(100) NOT NULL,
	-- 1-9
	daynumber number NOT NULL,
	itinerary_id nvarchar2(100) NOT NULL,
	-- 朝1　午後2　夜3
	timestate number NOT NULL,
	-- 1-3
	sequenceinf number NOT NULL,
	spot_id nvarchar2(100) NOT NULL,
	tour_content nvarchar2(1000),
	tour_name nvarchar2(100),
	tour_price number(10),
	PRIMARY KEY (spot_infid)
);



/* Create Foreign Keys */

ALTER TABLE spot
	ADD FOREIGN KEY (category3_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category1_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category2_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category6_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category4_id)
	REFERENCES category (category_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (category5_id)
	REFERENCES category (category_id)
;


ALTER TABLE flight_inf
	ADD FOREIGN KEY (departure_city_id)
	REFERENCES city (city_id)
;


ALTER TABLE flight_inf
	ADD FOREIGN KEY (arrival_city_id)
	REFERENCES city (city_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (city_id)
	REFERENCES city (city_id)
;


ALTER TABLE city
	ADD FOREIGN KEY (country_id)
	REFERENCES country (country_id)
;


ALTER TABLE itinerary
	ADD FOREIGN KEY (country_id)
	REFERENCES country (country_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (departure_flight_id)
	REFERENCES flight_inf (flight_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (arrival_flight_id)
	REFERENCES flight_inf (flight_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE spotinf
	ADD FOREIGN KEY (itinerary_id)
	REFERENCES itinerary (itinerary_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE itinerary
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (member_id)
	REFERENCES members (member_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (tour_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour2_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour1_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE spot
	ADD FOREIGN KEY (tour3_id)
	REFERENCES optional_tour (tour_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE reservation
	ADD FOREIGN KEY (product_id)
	REFERENCES product (product_id)
;


ALTER TABLE comment_inf
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE favorite
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE picture
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;


ALTER TABLE spotinf
	ADD FOREIGN KEY (spot_id)
	REFERENCES spot (spot_id)
;



/* Comments */

COMMENT ON COLUMN comment_inf.member_id IS 'メアド';
COMMENT ON COLUMN comment_inf.grade IS '1-5点とする';
COMMENT ON COLUMN favorite.member_id IS 'メアド';
COMMENT ON COLUMN itinerary.member_id IS 'メアド';
COMMENT ON COLUMN members.member_id IS 'メアド';
COMMENT ON COLUMN reservation.member_id IS 'メアド';
COMMENT ON COLUMN reservation.payment_method IS '1:クレジット
2:銀行振込';
COMMENT ON COLUMN spot.member_id IS 'メアド';
COMMENT ON COLUMN spotinf.daynumber IS '1-9';
COMMENT ON COLUMN spotinf.timestate IS '朝1　午後2　夜3';
COMMENT ON COLUMN spotinf.sequenceinf IS '1-3';



