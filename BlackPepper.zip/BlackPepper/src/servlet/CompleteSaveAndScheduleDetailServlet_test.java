package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SpotInf;
import dao.SpotInfDAO;
import ds.ConnectionManager;

/**
 * 保存確定・日程の詳細画面表示用サーブレット
 */
@WebServlet("/CompleteSaveAndScheduleDetailServlet_test")
public class CompleteSaveAndScheduleDetailServlet_test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<SpotInf> spotInfList = new ArrayList<SpotInf>();
		spotInfList = (List<SpotInf>) request.getAttribute("spotInfList");

		try (Connection con = ConnectionManager.getConnection()) {

			for (SpotInf spotInf : spotInfList) {
				if (spotInf.getSpotInfId() != null) {
					SpotInfDAO spotInfDAO = new SpotInfDAO(con);
					spotInfDAO.update(spotInf);
				}

			}
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}

		String url = "\\BF509_test.jsp";

		request.getRequestDispatcher(url).forward(request, response);
	}
}
