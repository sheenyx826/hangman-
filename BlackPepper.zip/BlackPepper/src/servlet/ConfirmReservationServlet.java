	
	package servlet;
	
	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;
	
	import javax.naming.NamingException;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;
	
	import bean.Card;
	import bean.Reservation;
	import constants.ConstURL;
	import ds.ConnectionManager;
	
	/**
	 * 予約内容確認画面表示用サーブレット
	 */
	@WebServlet("/ConfirmReservationServlet")
	public class ConfirmReservationServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
	
		protected void service(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
	
			String url = ConstURL.CONFIRM_RESERVATION_PATH;
	
			// reservationBean/reservationDAOがある想定
			HttpSession session = request.getSession();
			Reservation reservation = null;
	
			// 商品ＩＤ
			String productId = "1";
			String sql = "select * from product where product_id = ?";
			try (Connection con = ConnectionManager.getConnection()) {
				try (PreparedStatement ps = con.prepareStatement(sql)) {
				}
				// 大人人数
				String adultCount = request.getParameter("adultCount");
				session.setAttribute("adultCount", adultCount);
	
				// 子供人数
				String childCount = request.getParameter("childCount");
				session.setAttribute("childCount", childCount);
	
				// 出発日
				String startdate = request.getParameter("startDate");
				session.setAttribute("startdate", startdate);
				System.out.println(session.getAttribute(startdate));
				// 出発便
				String departure = request.getParameter("departure");
				session.setAttribute("departure", departure);
	
				// 到着便
				String arrival = request.getParameter("arrival");
				session.setAttribute("arrival", arrival);
	
				String payment = request.getParameter("payment");
				String howtopay;
				// 支払方法クレジットか銀行振り込みか？？？ちょっと良く分からない
				if (payment.equals("credit")) {
					howtopay = "クレジット";
				} else {
					howtopay = "銀行振り込み";
				}
				session.setAttribute("howtopay", howtopay);
	
				// カード情報
			
				String cardName = request.getParameter("cardName");
				String cardValidTermM = request.getParameter("cardValidTermM");
				String cardValidTermY = request.getParameter("cardValidTermY");
				String cardNo = request.getParameter("cardNo");
				String _cardSecCd2 = request.getParameter("_cardSecCd2");
				
				Card card = new Card();
				card.setCardName(cardName);
				card.setCardNo(cardNo);
				card.setCardValidTermM(cardValidTermM);
				card.setCardValidTermY(cardValidTermY);
				card.set_cardSecCd2(_cardSecCd2);
				session.setAttribute("card", card);
	
//				reservation = new Reservation();
				// reservation.setReservationId(productId);
				// reservation.setDepartureDay("start_date");
				// reservation.setDepartureFlightId("departure");
				// reservation.setArrivalFlightId("arrival");
				// reservation.setPaymentMethod(howtopay);
				System.out.println(reservation);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (NamingException e) {
				e.printStackTrace();
			}
			request.setAttribute("reservation", reservation);
			request.getRequestDispatcher(url).forward(request, response);
		}
	
	}
