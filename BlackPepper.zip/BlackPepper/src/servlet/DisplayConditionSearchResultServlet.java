package servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Product;
import constants.ConstURL;

/**
 * 条件検索結果画面表示サーブレット
 */
@WebServlet("/DisplayConditionSearchResultServlet")
public class DisplayConditionSearchResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.DISPLAY_CONDITION_SEARCH_RESULT_PATH;

		// 各種パラメータ値受け取る
		String country = request.getParameter("country");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		String minPrice = request.getParameter("minPrice");
		String maxPrice = request.getParameter("maxPrice");

		Timestamp timestampStartDate = new Timestamp(new Date(request.getParameter("startDate")).getTime());
		Timestamp timestampEndDate = new Timestamp(new Date(request.getParameter("endDate")).getTime());

		Product product = new Product();

		// 各項目セット

		product.setRemarks(country);
		product.setDepartureTime(timestampStartDate);
		product.setRemarks(country);
		product.setRemarks(country);
		product.setRemarks(country);

		/**
		 * 
		 * やること パラメータ受け取る beanにつめる DAO使う 結果受け取りリストにする リストをセットアトリビュート
		 * 
		 */

		request.getRequestDispatcher(url).forward(request, response);
	}

}
