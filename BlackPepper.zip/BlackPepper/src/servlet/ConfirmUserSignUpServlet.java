package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import constants.ConstErrorMessage;
import constants.ConstURL;
import constants.InputValueCheck;

/**
 * ユーザー登録確認画面表示用サーブレット
 */
@WebServlet("/ConfirmUserSignUpServlet")
public class ConfirmUserSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url;
		// Memberのインスタンス生成
		Member member = new Member();

		// ユーザー情報のパラメーター取得
		// 名前は結合
		String firstName = request.getParameter("firstName");
		String firstNameKana = request.getParameter("firstNameKana");
		String lastName = request.getParameter("lastName");
		String lastNameKana = request.getParameter("lastNameKana");
		String name = lastName + "  " + firstName;
		System.out.println("名前は" + name);
		// カナはデータには持たせない
		String nameKana = lastNameKana + "  " + firstNameKana;
		String password = request.getParameter("password");
		String phoneNum = request.getParameter("phoneNum");
		String eMail = request.getParameter("eMail");
		String zip = request.getParameter("zip");
		String address = request.getParameter("address");
		// カード情報
		String creditCardNum = request.getParameter("creditCardNum");
		// カード期限
		String creditCardValidMonth = request.getParameter("creditCardValidMonth");
		String creditCardValidYear = request.getParameter("creditCardValidYear");

		String creditCardSecurityCord = request.getParameter("creditCardSecurityCord");
		String creditCardName = request.getParameter("creditCardName");
		// パスポート
		String passportName = request.getParameter("passportName");
		String passportNum = request.getParameter("passportNum");

		// Memberのインスタンスに情報をセット
		member.setName(name);
		member.setPassword(password);
		member.setPhoneNum(phoneNum);
		member.setZip(zip);
		member.setAddress(address);
		member.seteMail(eMail);
		member.setCreditCardName(creditCardName);
		member.setCreditCardNum(creditCardNum);
		member.setCreditCardSecurityCord(creditCardSecurityCord);
		member.setCreditCardValidMonth(creditCardValidMonth);
		member.setCreditCardValidYear(creditCardValidYear);
		member.setPassportName(passportName);
		member.setPassportNum(passportNum);
		// errorのリストを生成
		List<String> errorL = new ArrayList<String>();
		url = ConstURL.DISPLAY_USER_SIGN_UP_PATH;
		// 入力検証(NULLチェック)
		// // 名前(姓)
		if (InputValueCheck.isEmpty(lastName) == true) {
			String lastNameNullError = ConstErrorMessage.lastNameNullError;
			errorL.add(lastNameNullError);
		}
		// else if (InputValueCheck.isSuitableFormat(lastName, "[\u3041-\u3096]") ==
		// false
		// || InputValueCheck.isSuitableFormat(lastName, " [\\u30A0-\\u30FF]") == false
		// || InputValueCheck.isSuitableFormat(lastName,
		// " [々〇〻\\u3400-\\u9FFF\\uF900-\\uFAFF]|[\\uD840-\\uD87F][\\uDC00-\\uDFFF]") ==
		// false) {
		// String lastNameValueError = ConstErrorMessage.lastNameValueError;
		// errorL.add(lastNameValueError);
		// }
		// 名前(名)
		if (InputValueCheck.isEmpty(firstName) == true) {
			String firstNameNullError = ConstErrorMessage.firstNameKanaNullError;
			errorL.add(firstNameNullError);
		}
		// else if (InputValueCheck.isSuitableFormat(firstName, "[\u3041-\u3096]") ==
		// false
		// || InputValueCheck.isSuitableFormat(firstName, " [\\u30A0-\\u30FF]") == false
		// || InputValueCheck.isSuitableFormat(firstName,
		// " [々〇〻\\u3400-\\u9FFF\\uF900-\\uFAFF]|[\\uD840-\\uD87F][\\uDC00-\\uDFFF]") ==
		// false) {
		// String firstNameValueError = ConstErrorMessage.firstNameValueError;
		// errorL.add(firstNameValueError);
		// }
		// 名前(セイ)
		if (InputValueCheck.isEmpty(lastNameKana) == true) {
			String lastNameKanaNullError = ConstErrorMessage.lastNameKanaNullError;
			errorL.add(lastNameKanaNullError);
		}
		// else if (InputValueCheck.isSuitableFormat(lastNameKana, "[\u30A0-\u30FF]")
		// == false) {
		// String lastNameKanaNullError = ConstErrorMessage.lastNameKanaNullError;
		// errorL.add(lastNameKanaNullError);
		// }
		// 名前(メイ)
		if (InputValueCheck.isEmpty(firstNameKana) == true) {
			String firstNameKanaNullError = ConstErrorMessage.firstNameKanaNullError;
			errorL.add(firstNameKanaNullError);
		}
		// else if (InputValueCheck.isSuitableFormat(firstNameKana, "[\u30A0-\u30FF]")
		// == false) {
		// String firstNameKanaValueError = ConstErrorMessage.firstNameKanaValueError;
		// errorL.add(firstNameKanaValueError);
		// }
		// password
		if (InputValueCheck.isEmpty(password) == true) {
			String passwordNullError = ConstErrorMessage.passwordNullError;
			errorL.add(passwordNullError);
		} else if (!InputValueCheck.isSuitableFormat(password, "[0-9a-zA-Z]{4,8}")) {
			String passwordValueError = ConstErrorMessage.passwordValueError;
			errorL.add(passwordValueError);
		}

		// 電話番号
		if (InputValueCheck.isEmpty(phoneNum) == true) {
			String phoneNumNullError = ConstErrorMessage.phoneNumNullError;
			errorL.add(phoneNumNullError);
		} else if (InputValueCheck.isSuitableFormat(phoneNum, "[0-9]{10,11}") == false) {
			String phoneNumValueError = ConstErrorMessage.phoneNumValueError;
			errorL.add(phoneNumValueError);
		}
		// メールアドレス
		if (InputValueCheck.isEmpty(eMail) == true) {
			String eMailNullError = ConstErrorMessage.eMailNullError;
			errorL.add(eMailNullError);
		} else if (InputValueCheck.isSuitableFormat(eMail, ".{1,50}") == false) {
			String eMailValueError = ConstErrorMessage.eMailValueError;
			errorL.add(eMailValueError);
		}
		// 郵便番号
		if (InputValueCheck.isEmpty(zip) == true) {
			String zipNullError = ConstErrorMessage.zipNullError;
			errorL.add(zipNullError);
		} else if (InputValueCheck.isSuitableFormat(zip, "[0-9]{7}") == false) {
			String zipValueError = ConstErrorMessage.zipValueError;
			errorL.add(zipValueError);
		}
		// パスポート名義
		if (InputValueCheck.isEmpty(passportName) == true) {
			String passportNameNullError = ConstErrorMessage.passportNameNullError;
			errorL.add(passportNameNullError);
		} else if (InputValueCheck.isSuitableFormat(passportName, "[A-Z]{1,100}") == false) {
			String passportNameValueError = ConstErrorMessage.passportNameValueError;
			errorL.add(passportNameValueError);
		}
		// パスポート番号
		if (InputValueCheck.isEmpty(passportNum) == true) {
			String passportNumNullError = ConstErrorMessage.passportNumNullError;
			errorL.add(passportNumNullError);
		} else if (InputValueCheck.isSuitableFormat(passportNum, "[0-9a-zA-Z]{7}") == false) {
			String passportNumValueError = ConstErrorMessage.passportNumValueError;
			errorL.add(passportNumValueError);
		}
		// カードについて
		if (!creditCardNum.isEmpty()) {
			if (InputValueCheck.isSuitableFormat(creditCardNum, "[0-9]{16}") == false) {
				String creditCardNumValueError = ConstErrorMessage.creditCardNumValueError;
				errorL.add(creditCardNumValueError);
			}
			// カード期限
			if (InputValueCheck.isSuitableFormat(creditCardValidMonth, "[0-9]{1,2}") == false) {
				String creditCardValidMonthValueError = ConstErrorMessage.creditCardValidMonthValueError;
				errorL.add(creditCardValidMonthValueError);
			}
			if (InputValueCheck.isSuitableFormat(creditCardValidYear, "[0-9]{4}") == false) {
				String creditCardValidYearValueError = ConstErrorMessage.creditCardValidYearValueError;
				errorL.add(creditCardValidYearValueError);
			}
			// カードセキュリティコード
			if (InputValueCheck.isSuitableFormat(creditCardSecurityCord, "[0-9]{3}") == false) {
				String creditCardSecurityCodeValueError = ConstErrorMessage.creditCardSecurityCodeValueError;
				errorL.add(creditCardSecurityCodeValueError);
			}
			// カード名義
			if (InputValueCheck.isSuitableFormat(creditCardName, "[A-Z]{1,100}") == false) {
				String creditCardNameValueError = ConstErrorMessage.creditCardNameValueError;
				errorL.add(creditCardNameValueError);
			}
		}

		if (!errorL.isEmpty()) {
			request.setAttribute("errorL", errorL);
			request.setAttribute("member", member);
			request.setAttribute("firstName", firstName);
			request.setAttribute("firstNameKana", firstNameKana);
			request.setAttribute("lastName", lastName);
			request.setAttribute("lastNameKana", lastNameKana);

			request.getRequestDispatcher(url).forward(request, response);
			return;
		}

		// session取得及び、ユーザー情報をsessionにセット
		HttpSession session = request.getSession();
		session.setAttribute("member", member);
		session.setAttribute("nameKana", nameKana);
		session.setAttribute("lastName", request.getParameter("lastName"));
		session.setAttribute("firstName", request.getParameter("firstName"));
		session.setAttribute("lastNameKana", request.getParameter("lastNameKana"));
		session.setAttribute("firstNameKana", request.getParameter("firstNameKana"));
		url = ConstURL.CONFIRM_USER_SIGN_UP_PATH;
		request.getRequestDispatcher(url).forward(request, response);
	}
}
