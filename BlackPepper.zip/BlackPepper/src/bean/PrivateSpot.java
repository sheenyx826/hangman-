package bean;

import java.io.Serializable;

public class PrivateSpot implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String privateSpotId;
	private String privateSpotName;
	private String memberId;
	public String getPrivateSpotId() {
		return privateSpotId;
	}
	public void setPrivateSpotId(String privateSpotId) {
		this.privateSpotId = privateSpotId;
	}
	public String getPrivateSpotName() {
		return privateSpotName;
	}
	public void setPrivateSpotName(String privateSpotName) {
		this.privateSpotName = privateSpotName;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	@Override
	public String toString() {
		return "PrivateSpot [privateSpotId=" + privateSpotId + ", privateSpotName=" + privateSpotName + ", memberId="
				+ memberId + "]";
	}



}
