package bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class Card implements Serializable {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	private String cardName;
	private String cardValidTermM;
	private String cardValidTermY;
	private String cardNo;
	private String _cardSecCd2;
	
	
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardValidTermM() {
		return cardValidTermM;
	}
	public void setCardValidTermM(String cardValidTermM) {
		this.cardValidTermM = cardValidTermM;
	}
	public String getCardValidTermY() {
		return cardValidTermY;
	}
	public void setCardValidTermY(String cardValidTermY) {
		this.cardValidTermY = cardValidTermY;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String get_cardSecCd2() {
		return _cardSecCd2;
	}
	public void set_cardSecCd2(String _cardSecCd2) {
		this._cardSecCd2 = _cardSecCd2;
	}
	
	
	
	
	
}