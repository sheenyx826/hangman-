package TestServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Member;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * Servlet implementation class SearchByMemberId
 */
@WebServlet("/SearchByMemberId")
public class SearchByMemberId extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchByMemberId() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");

		try (Connection con = ConnectionManager.getConnection()) {
			MembersDAO dao = new MembersDAO(con);
			List<Member> memberList = new ArrayList<Member>();

			memberList = dao.selectById(id);
			request.setAttribute("memberList", memberList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
		}

		String url = "\\SearchMemberPage.jsp";
		request.getRequestDispatcher(url).forward(request, response);

	}

}
