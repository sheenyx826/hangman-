package TestServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PrivateSpot;
import dao.PrivateSpotDAO;
import ds.ConnectionManager;

/**
 * 従業員情報一覧表示サーブレット
 */
@WebServlet("/ViewPrivateSpotServlet")
public class ViewPrivateSpotServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try (Connection con = ConnectionManager.getConnection()) {
			PrivateSpotDAO dao = new PrivateSpotDAO(con);
			List<PrivateSpot> privateSpotList = dao.selectAll();
			request.setAttribute("privateSpotList", privateSpotList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
		}
		// String url = ConstURL.ViewPrivateSpot_PATH;
		//
		// request.getRequestDispatcher(url).forward(request, response);
	}

}
