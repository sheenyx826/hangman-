package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean_sample.Employee;

/**
 * 従業員DAO
 *
 * @author yokin
 */

public class EmployeesDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */
	public EmployeesDAO(Connection con) {
		this.con = con;
	}

	//
	/**
	 * 従業員情報登録
	 * 
	 * @param employee
	 * @return
	 * @throws SQLException
	 */
	public int insert(Employee employee) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO EMPLOYEES(EMPLOYEE_ID, EMPLOYEE_NAME, EMPLOYEE_AGE)" + "VALUES(?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, employee.getId());
			ps.setString(2, employee.getName());
			ps.setInt(3, employee.getAge());
			cnt = ps.executeUpdate();
		}
		return cnt;
	}

	/**
	 * 従業員情報全件検索
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<Employee> selectAll() throws SQLException {
		String sql = "SELECT EMPLOYEE_ID,EMPLOYEE_NAME,EMPLOYEE_AGE FROM EMPLOYEES ORDER BY EMPLOYEE_ID";
		List<Employee> list = new ArrayList<Employee>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setId(rs.getString("EMPLOYEE_ID"));
				employee.setName(rs.getString("EMPLOYEE_NAME"));
				employee.setAge(rs.getInt("EMPLOYEE_AGE"));
				list.add(employee);
			}
		}
		return list;
	}

	/**
	 * 従業員情報単一取得
	 * 
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public Employee selectById(String id) throws SQLException {
		Employee employee = null;
		String sql = "SELECT *FROM EMPLOYEES WHERE EMPLOYEE_ID =?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					employee = new Employee();
					employee.setId(rs.getString("EMPLOYEE_ID"));
					employee.setName(rs.getString("EMPLOYEE_NAME"));
					employee.setAge(rs.getInt("EMPLOYEE_AGE"));
				}
			}
		}
		return employee;
	}

	/**
	 * 従業員情報変更
	 * 
	 * @param employee
	 * @return
	 * @throws SQLException
	 */
	public int update(Employee employee) throws SQLException {

		int cnt = 0;
		String sql = "UPDATE EMPLOYEES SET EMPLOYEE_NAME = ?, EMPLOYEE_AGE = ? WHERE EMPLOYEE_ID = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, employee.getName());
			ps.setInt(2, employee.getAge());
			ps.setString(3, employee.getId());
			cnt = ps.executeUpdate();
		}
		return cnt;

	}

}