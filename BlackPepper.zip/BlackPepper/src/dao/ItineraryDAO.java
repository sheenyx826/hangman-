package dao;

import java.sql.Connection;

/**
 * 旅程表DAO
 *
 * @author yokin
 */

public class ItineraryDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */
	public ItineraryDAO(Connection con) {
		this.con = con;
	}

	// public int delete(String ItineraryId) throws SQLException {
	//
	// int cnt = 0;
	// String sql = "DELETE FROM ITINERARY WHERE ITINERARY_ID = ?";
	//
	// Itinerary itinerary = new Itinerary();
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	//
	// ps.setString(1, itinerary.());
	// cnt = ps.executeUpdate();
	// }

}