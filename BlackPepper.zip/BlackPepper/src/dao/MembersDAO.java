package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Member;

/**
 * テンプレートテーブルを管理するクラス。
 *
 * @author yokin
 */
public class MembersDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public MembersDAO(Connection con) {
		this.con = con;
	}

	/**
	 * 会員情報全件検索
	 *
	 * @return
	 * @throws SQLException
	 */

	public int insert(Member member) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO MEMBERS(MEMBER_ID, MEMBER_NAME, MEMBER_PASSWORD, MEMBER_ADDRESS, MEMBER_POSTCODE, MEMBER_PHONE, CREDITCARD_MONTH, CREDITCARD_YEAR, CREDITCARD_NAME, CREDITCARD_NUMBER, CREDITCARD_CODE, PASSPORT_NAME, PASSPORT_NUMBER)"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, member.geteMail());
			ps.setString(2, member.getName());
			ps.setString(3, member.getPassword());
			ps.setString(4, member.getAddress());
			ps.setString(5, member.getZip());
			ps.setString(6, member.getPhoneNum());
			ps.setString(7, member.getCreditCardValidMonth());
			ps.setString(8, member.getCreditCardValidYear());
			ps.setString(9, member.getCreditCardName());
			ps.setString(10, member.getCreditCardNum());
			ps.setString(11, member.getCreditCardSecurityCord());
			ps.setString(12, member.getPassportName());
			ps.setString(13, member.getPassportNum());
			cnt = ps.executeUpdate();
		}
		return cnt;
	}

	public List<Member> selectAll() throws SQLException {
		String sql = "SELECT * FROM MEMBERS ORDER BY MEMBER_ID";
		List<Member> list = new ArrayList<Member>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Member memberbp = new Member();
				// memberbp.setId(rs.getString("MEMBER_ID"));
				// memberbp.setName(rs.getString("MEMBER_NAME"));

				list.add(memberbp);
			}
		}
		return list;
	}

	public List<Member> selectById(String id) throws SQLException {
		String sql = "SELECT *FROM MEMBERS WHERE MEMBER_ID LIKE '%'||?||'%' ";
		List<Member> list = new ArrayList<Member>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Member member = new Member();
					// member.setId(rs.getString("MEMBER_ID"));
					member.setName(rs.getString("MEMBER_NAME"));
					list.add(member);
				}
			}
		}
		return list;
	}

	/**
	 * 
	 * @param id
	 * @return
	 * @throws SQLException
	 *
	 * 
	 *             loginチェックをするメソッド 引数でIDとパスワードをうけとり、DB上で一致したらint型の1を、その他なら0を返す
	 *
	 */
	public int checkLogin(String id, String pass) throws SQLException {
		String sql = "SELECT MEMBER_ID,MEMBER_PASSWORD,MEMBER_NAME FROM MEMBERS WHERE MEMBER_ID LIKE '%'||?||'%' ";

		// SQLを実行した結果を格納する変数
		String resultId;
		String resultPass;

		// loginチェックのflag
		int loginFlag = 0;

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			// 入力されたIDをセット
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					resultId = (rs.getString("MEMBER_ID"));
					resultPass = (rs.getString("MEMBER_PASSWORD"));

					// 入力されたパスワードとDBのパスワードが一致したらフラッグを変更
					if (pass.equals(resultPass)) {
						loginFlag = 1;
					}
				}

			}

		}

		return loginFlag;
	}

	// public Member confirmById(String id) throws SQLException {
	// String sql = "SELECT * FROM MEMBERS WHERE MEMBER_ID =? ";
	// Member member = null;
	//
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	// ps.setString(1, id);
	// try (ResultSet rs = ps.executeQuery()) {
	// if (rs.next()) {
	// member = new Member();
	//// member.setId(rs.getString("MEMBER_ID"));
	//// member.setName(rs.getString("MEMBER_NAME"));
	//
	// }
	// }
	// }
	//// return memberbp;
	// }

	public int update(Member member) throws SQLException {

		int cnt = 0;
		String sql = "UPDATE MEMBERS SET MEMBER_NAME = ? WHERE MEMBER_ID = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			// ps.setString(1, member.getName());
			// ps.setString(2, member.getId());
			cnt = ps.executeUpdate();
		}
		return cnt;

	}

	public int DELETE(Member member) throws SQLException {

		int cnt = 0;
		String sql = "DELETE FROM  MEMBERS WHERE MEMBER_ID = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			// ps.setString(1, member.getId());
			cnt = ps.executeUpdate();
		}
		return cnt;

	}

}