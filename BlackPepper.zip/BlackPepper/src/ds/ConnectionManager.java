package ds;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ConnectionManager {
	private static final String JNDI_NAME = "java:comp/env/jdbc/oracle";

	/**
	 * コネクションを取得して返すメソッド
	 * 
	 * @return コネクション
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static Connection getConnection() throws NamingException, SQLException {
		InitialContext context = null;
		DataSource ds = null;

		try {
			// InitialContextを作成し、データソースを取得する
			context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/jdbc/oracle");
		} finally {
			if (context != null) {
				try {
					context.close();
				} catch (NamingException e) {
					e.printStackTrace();
				}
			}
		}
		return ds.getConnection();
	}
}
