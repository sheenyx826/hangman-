package constants;

public class RankAndPoint {
	/**
	 * ランクとポイントのクラス
	 * 
	 *
	 */
	public static int userRank(int userPoint) {
		int rank;
		if (userPoint > 300) {
			rank = 6;
		} else if (userPoint > 200) {
			rank = 5;
		} else if (userPoint > 100) {
			rank = 4;
		} else if (userPoint > 50) {
			rank = 3;
		} else if (userPoint > 30) {
			rank = 2;
		} else {
			rank = 1;
		}
		return rank;
	}

	public static int addUserPointByReservation(int userPoint) {
		userPoint += 30;
		return userPoint;
	}

	public static int addUserPointByFavoriteTrip(int userPoint) {
		userPoint += 20;
		return userPoint;
	}

	public static int addUserPointByFavoriteSpot(int userPoint) {
		userPoint += 10;
		return userPoint;
	}
}
