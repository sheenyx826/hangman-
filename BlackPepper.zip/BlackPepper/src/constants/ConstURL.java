package constants;

/**
 * @author URLを保持するクラス
 *
 */
public class ConstURL {
	public static final String SELECT_FREE_TOUR_PATH = "\\WEB-INF\\BF0501.jsp";
	public static final String CREATE_FREE_TOUR_AND_DISPLAY_RANKING_PATH = "\\WEB-INF\\BF0503.jsp";
	public static final String MODIFICATION_SAVE_SCHEDULE_PATH = "\\WEB-INF\\BF0503.jsp";
	public static final String SEARCH_AND_DISPLAY_SPOT_PATH = "\\WEB-INF\\BF0504.jsp";
	public static final String DISPLAY_OTHER_USER_SCHEDULE_DETAIL_PATH = "\\WEB-INF\\BF0506.jsp";
	public static final String DISPLAY_FAVORITE_SCHEDULE_PATH = "\\WEB-INF\\BF0508.jsp";
	public static final String COMPLETE_SAVE_AND_SCHEDULE_DETAIL_PATH = "\\WEB-INF\\BF0509.jsp";
	public static final String DISPLAY_SPOT_DETAIL_PATH = "\\WEB-INF\\BF0512.jsp";
	public static final String DISPLAY_ADD_SPOT_PATH = "\\WEB-INF\\BF0513.jsp";

	public static final String DISPLAY_USER_LOGIN_PATH = "\\WEB-INF\\P01011.jsp";
	public static final String DISPLAY_USER_SIGN_UP_PATH = "\\WEB-INF\\P02011.jsp";
	public static final String CONFIRM_USER_SIGN_UP_PATH = "\\WEB-INF\\P02012.jsp";
	public static final String COMPLETE_USER_SIGN_UP_PATH = "\\WEB-INF\\P02013.jsp";
	public static final String DISPLAY_MY_PAGE_PATH = "\\WEB-INF\\P02014.jsp";
	public static final String VIEW_TOP_PAGE_PATH = "\\WEB-INF\\P03010.jsp";
	public static final String SEARCH_AND_DISPLAY_PRODUCT_PATH = "\\WEB-INF\\P03011.jsp";
	public static final String VALIDATE_USER_LOGIN_PATH = "\\WEB-INF\\P03011.jsp";
	public static final String DISPLAY_PRODUCT_DETAIL_PATH = "\\WEB-INF\\P03012.jsp";
	public static final String DISPLAY_CAMPAIGN_PATH = "\\WEB-INF\\P03013.jsp";
	public static final String DISPLAY_CONDITION_SEARCH_RESULT_PATH = "\\WEB-INF\\P03111.jsp";
	public static final String DISPLAY_RESERVATION_PATH = "\\WEB-INF\\P04011.jsp";
	public static final String COMPLETE_RESERVATION_PATH = "\\WEB-INF\\P04012.jsp";
	public static final String CONFIRM_CANCEL_RESERVATION_PATH = "\\WEB-INF\\P04013.jsp";
	public static final String COMPLETE_CANCEL_RESERVATION_PATH = "\\WEB-INF\\P04014.jsp";
	public static final String CONFIRM_RESERVATION_PATH = "\\WEB-INF\\P04021.jsp";
	public static final String DISPLAY_RESERVATION_HISTORY_PATH = "\\WEB-INF\\P05011.jsp";
	public static final String DISPLAY_RESERVATION_HISTORY_DETAIL_PATH = "\\WEB-INF\\P05012.jsp";

	public static final String DISPLAY_OTHER_USER_DETAIL_PATH = "\\WEB-INF\\P07010.jsp";
}