package bean;

import java.io.Serializable;

import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class EmployeeInf
 */
@WebServlet("/EmployeeInf")
public class EmployeeInf implements Serializable {
	private int id;
	private String kana;
	private String name;
	private String dept;
	private String auth;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKana() {
		return kana;
	}

	public void setKana(String kana) {
		this.kana = kana;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String depa) {
		this.dept = depa;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public EmployeeInf() {

	}

	@Override
	public String toString() {
		return "EmployeeInf [id=" + id + ", kana=" + kana + ", name=" + name + ", dept=" + dept + ", auth=" + auth
				+ "]";
	}

}
