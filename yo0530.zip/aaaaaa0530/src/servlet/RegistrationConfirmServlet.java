package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.EmployeeInf;

/**
 * Servlet implementation class RegistrationConfirmServlet
 */
@WebServlet("/RegistrationConfirmServlet")
public class RegistrationConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		// フォームからデータを取得する
		int id = Integer.parseInt(request.getParameter("empCode"));
		String kana = request.getParameter("kana");
		String name = request.getParameter("name");
		String dept = request.getParameter("dept");
		String auth = request.getParameter("role");

		// Actorオブジェクトを生成
		EmployeeInf user = new EmployeeInf();

		// 取得したデータをセッターを介してそれぞれセット
		user.setId(id);
		user.setKana(kana);
		user.setName(name);
		user.setDept(dept);
		user.setAuth(auth);

		// セッションオブジェクトを取得
		HttpSession session = request.getSession();

		// セッションオブジェクトにActorオブジェクトをセット
		session.setAttribute("user", user);

		// confirmActor.jspにフォワード
		request.getRequestDispatcher("WEB-INF/employeeRegistrationConfirm.jsp").forward(request, response);
	}

}
