package TestServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean_sample.Employee;
import dao.EmployeesDAO;
import ds.ConnectionManager;

/**
 * 従業員情報変更画面表示用サーブレット
 */
@WebServlet("/UpdateInputServlet")
public class UpdateInputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String errorURL = "ViewEmployeesServlet";
		String id = request.getParameter("id");

		if (id == null || id.isEmpty()) {

			String error = "編集したい従業員の行を選んでください。";
			request.setAttribute("error", error);
			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		try (Connection con = ConnectionManager.getConnection()) {
			EmployeesDAO dao = new EmployeesDAO(con);
			Employee employee = dao.selectById(id);
			request.setAttribute("employee", employee);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
		}

		// String url = ConstURL.UpdateInput_PATH;
		// request.getRequestDispatcher(url).forward(request, response);

	}

}
