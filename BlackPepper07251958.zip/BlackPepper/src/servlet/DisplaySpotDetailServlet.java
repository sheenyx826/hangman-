package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Category;
import bean.Comment;
import bean.OptionalTour;
import bean.Spot;
import constants.ConstURL;
import dao.CategoryDAO;
import dao.CommentDAO;
import dao.MembersDAO;
import dao.OptionalTourDAO;
import dao.SpotDAO;
import ds.ConnectionManager;

/**
 * スポットの詳細画面表示用サーブレット コメント表示機能あり
 */
@WebServlet("/DisplaySpotDetailServlet")
public class DisplaySpotDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String url = ConstURL.DISPLAY_SPOT_DETAIL_PATH;
		String addedSpotId = request.getParameter("addedSpotId");
		System.out.println(addedSpotId);
		try (Connection con = ConnectionManager.getConnection();) {
			Spot addedSpot = new Spot();

			SpotDAO dao = new SpotDAO(con);
			addedSpot = dao.selectById(addedSpotId);
			List<OptionalTour> tourlist = new ArrayList<OptionalTour>();
			OptionalTour tour = new OptionalTour();
			String Category1Id = addedSpot.getCategory1Id();
			String Category2Id = addedSpot.getCategory2Id();
			String Category3Id = addedSpot.getCategory3Id();
			String Category4Id = addedSpot.getCategory4Id();
			String Category5Id = addedSpot.getCategory5Id();
			String Category6Id = addedSpot.getCategory6Id();
			String Tour1Id = addedSpot.getTour1Id();
			String Tour2Id = addedSpot.getTour2Id();
			String Tour3Id = addedSpot.getTour3Id();
			String MemberId = addedSpot.getMemberId();
			String imgPicLink = addedSpot.getSpotId() + "spotImg";
			request.setAttribute("imgPicLink", imgPicLink);
			System.out.println(imgPicLink);

			if (Tour1Id != null) {
				try (Connection conTour1Id = ConnectionManager.getConnection();) {
					OptionalTourDAO daoTour1Id = new OptionalTourDAO(conTour1Id);
					tour = daoTour1Id.selectByTourId(Tour1Id);
					tourlist.add(tour);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Tour2Id != null) {
				try (Connection conTour2Id = ConnectionManager.getConnection();) {
					OptionalTourDAO daoTour2Id = new OptionalTourDAO(conTour2Id);
					tour = daoTour2Id.selectByTourId(Tour2Id);
					tourlist.add(tour);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Tour3Id != null) {
				try (Connection conTour3Id = ConnectionManager.getConnection();) {
					OptionalTourDAO daoTour3Id = new OptionalTourDAO(conTour3Id);
					tour = daoTour3Id.selectByTourId(Tour3Id);
					tourlist.add(tour);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			request.setAttribute("tourlist", tourlist);

			if (MemberId != null) {
				try (Connection conMember = ConnectionManager.getConnection();) {
					MembersDAO daoMember = new MembersDAO(conMember);
					String MemberName = daoMember.DisplayMemberNameByMemberId(MemberId);
					request.setAttribute("MemberName", MemberName);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category1Id != null) {
				try (Connection con1 = ConnectionManager.getConnection();) {
					CategoryDAO dao1 = new CategoryDAO(con1);
					Category Category1 = dao1.selectByCategoryId(Category1Id);
					request.setAttribute("Category1", Category1);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category2Id != null) {
				try (Connection con2 = ConnectionManager.getConnection();) {
					CategoryDAO dao2 = new CategoryDAO(con2);
					Category Category2 = dao2.selectByCategoryId(Category2Id);
					request.setAttribute("Category2", Category2);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category3Id != null) {
				try (Connection con3 = ConnectionManager.getConnection();) {
					CategoryDAO dao3 = new CategoryDAO(con3);
					Category Category3 = dao3.selectByCategoryId(Category3Id);
					request.setAttribute("Category3", Category3);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category4Id != null) {
				try (Connection con4 = ConnectionManager.getConnection();) {
					CategoryDAO dao4 = new CategoryDAO(con4);
					Category Category4 = dao4.selectByCategoryId(Category4Id);
					request.setAttribute("Category4", Category4);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category5Id != null) {
				try (Connection con5 = ConnectionManager.getConnection();) {
					CategoryDAO dao5 = new CategoryDAO(con5);
					Category Category5 = dao5.selectByCategoryId(Category5Id);
					request.setAttribute("Category5", Category5);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			if (Category6Id != null) {
				try (Connection con6 = ConnectionManager.getConnection();) {
					CategoryDAO dao6 = new CategoryDAO(con6);
					Category Category6 = dao6.selectByCategoryId(Category6Id);
					request.setAttribute("Category6", Category6);

				} catch (SQLException e) {
					throw new ServletException(e);
				} catch (NamingException e) {
					throw new ServletException(e);
				}
			}

			session.setAttribute("addedSpot", addedSpot);

		} catch (SQLException e) {
			throw new ServletException(e);
		} catch (NamingException e) {
			throw new ServletException(e);
		}

		// JSP一覧ページから選択されたスポットのIDを受け取る
		String spotId = request.getParameter("addedSpotId");
		Spot spot = new Spot();
		List<Comment> commentList = null;
		try (Connection con = ConnectionManager.getConnection();) {

			// spotIDをもとに一致するspotを検索しsetAtribute
			SpotDAO spotDAO = new SpotDAO(con);
			spot = spotDAO.selectById(spotId);

			// コメント生成部分
			CommentDAO commentDAO = new CommentDAO(con);
			commentList = commentDAO.commentAll(spotId);
			System.out.println(commentList.get(0));
		} catch (SQLException e) {
			throw new ServletException(e);
		} catch (NamingException e) {
			throw new ServletException(e);
		}

		session.setAttribute("commentList", commentList);
		session.setAttribute("spot", spot);
		request.getRequestDispatcher(url).forward(request, response);
	}

}
