package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constants.ConstURL;

/**
 * Servlet implementation class Logout
 * 
 * ログアウトを行い、TOPページに戻らせるサーブレット セッションを放棄する
 * 
 */
@WebServlet("/Logout")
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("ログアウトサーブレット入った");
		HttpSession session = request.getSession();

		String url = ConstURL.VIEW_TOP_PAGE_PATH;

		session.invalidate();
		// session.setAttribute("userId", "未ログインです");

		request.getRequestDispatcher(url).forward(request, response);

	}
}
