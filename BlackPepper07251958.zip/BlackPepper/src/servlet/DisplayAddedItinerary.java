package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Itinerary;
import bean.Reservation;
import bean.SpotInf;
import constants.ConstURL;
import dao.ItineraryDAO;
import dao.ReservationDAO;
import dao.SpotInfDAO;
import ds.ConnectionManager;

/**
 * スポットの追加画面表示用サーブレット
 */
@WebServlet("/DisplayAddedItinerary")
public class DisplayAddedItinerary extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		Map<String, SpotInf> map_tmp = new HashMap<String, SpotInf>();
		map_tmp = (Map<String, SpotInf>) session.getAttribute("map");
		// for (String key : map_tmp.keySet()) {
		// System.out.println(key);
		//
		// }

		// try (Connection con = ConnectionManager.getConnection()) {
		//
		// } catch (SQLException | NamingException e) {
		// throw new ServletException(e);
		//
		// }
		String tourName = request.getParameter("tourName");
		String tourContent = request.getParameter("tourContent");
		System.out.println(tourName);
		System.out.println(tourContent);

		String IntineraryId = null;
		for (SpotInf val : map_tmp.values()) {

			System.out.println(val.getDayNumber());
			System.out.println(val.getTimeState());
			System.out.println(val.getSequenceInf());

			System.out.println(val.getSpotInfId());
			System.out.println(val.getItineraryId());
			System.out.println(val.getSpotId());
			IntineraryId = val.getItineraryId();
			String spotId = val.getSpotId();
			if (spotId != null) {
				try (Connection con = ConnectionManager.getConnection()) {

					SpotInfDAO dao = new SpotInfDAO(con);
					dao.update(val);

				} catch (SQLException | NamingException e) {
					throw new ServletException(e);

				}

			}

		}
		if (IntineraryId != null) {

			try (Connection con = ConnectionManager.getConnection()) {
				Itinerary itinerary = new Itinerary();
				itinerary.setItineraryId(IntineraryId);
				itinerary.setItineraryOverview(tourContent);
				itinerary.setItineraryName(tourName);
				ItineraryDAO dao = new ItineraryDAO(con);
				int cnt = dao.updateNameAndContent(itinerary);
				System.out.println(cnt);
				System.out.println(IntineraryId);
				System.out.println("成功した");

			} catch (SQLException | NamingException e) {
				throw new ServletException(e);

			}
		}

		try (Connection con = ConnectionManager.getConnection()) {
			List<Itinerary> itineraryList = new ArrayList<Itinerary>();

			String userId = (String) session.getAttribute("userId_tmp");

			ItineraryDAO dao = new ItineraryDAO(con);
			itineraryList = dao.selectByMemberId(userId);
			request.setAttribute("itineraryList", itineraryList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

//		予約したフリーツアー（旅程表）を表示　＠叶
		try (Connection con = ConnectionManager.getConnection()) {
			List<Reservation> reservationList = new ArrayList<Reservation>();
			List<Itinerary> itineraryList = new ArrayList<Itinerary>();

			String userId = (String) session.getAttribute("userId_tmp");

			ReservationDAO dao = new ReservationDAO(con);
			reservationList = dao.selectReservationItineraryHistory(userId);
			for (Reservation reservation : reservationList) {

				ItineraryDAO itineraryDao=new ItineraryDAO(con);
				itineraryList.add(itineraryDao.selectByItineraryId(reservation.getItineraryId()));
			}


			request.setAttribute("bookItineraryList", itineraryList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);

		}

		String url = ConstURL.DISPLAY_MY_PAGE_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}

}
