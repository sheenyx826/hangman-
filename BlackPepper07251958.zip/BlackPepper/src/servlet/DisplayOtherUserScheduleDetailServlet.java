package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.SpotInf;
import constants.ConstURL;
import dao.SpotDAO;
import dao.SpotInfDAO;
import ds.ConnectionManager;

/**
 * 日程詳細画面表示用サーブレット
 */
@WebServlet("/DisplayOtherUserScheduleDetailServlet")
public class DisplayOtherUserScheduleDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		String ItineraryId = request.getParameter("itineraryId");
		String ItineraryName = request.getParameter("itineraryName");
		request.setAttribute("ItineraryName", ItineraryName);
		request.setAttribute("ItineraryId", ItineraryId);

		System.out.println("----------");
		System.out.println(ItineraryId);
		System.out.println("----------");
		HttpSession session = request.getSession();

		try (Connection con = ConnectionManager.getConnection()) {
			List<SpotInf> list = new ArrayList<SpotInf>();
			Map<String, SpotInf> map = new HashMap<String, SpotInf>();

			SpotInfDAO spotInfDAO = new SpotInfDAO(con);
			list = spotInfDAO.selectByItineraryId(ItineraryId);
			int i = 1;

			for (SpotInf spotInf : list) {
				String iString = String.valueOf(i);
				if (spotInf.getSpotId() != null) {
					map.put(iString, spotInf);
					String key = "spotName" + iString;
					try (Connection con1 = ConnectionManager.getConnection()) {
						SpotDAO dao = new SpotDAO(con1);
						String addedSpotName = dao.DisplaySpotNameById(spotInf.getSpotId());
						session.setAttribute(key, addedSpotName);
					} catch (SQLException | NamingException e) {
						throw new ServletException(e);
					}
				}

				i++;
			}
			String date = String.valueOf(i / 9);

			session.setAttribute("date", date);
			session.setAttribute("map", map);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}

		String url = ConstURL.DISPLAY_OTHER_USER_SCHEDULE_DETAIL_PATH;

		request.getRequestDispatcher(url).forward(request, response);
	}

}
