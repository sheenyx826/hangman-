package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.OptionalTour;

/**
 * オプショナルツアーDAO
 *
 * @author yokin
 */

public class OptionalTourDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public OptionalTourDAO(Connection con) {
		this.con = con;
	}

	public OptionalTour selectByTourId(String tourId) throws SQLException {
		OptionalTour optionalTour = null;

		String sql = "SELECT * FROM OPTIONAL_TOUR WHERE TOUR_ID =?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, tourId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					optionalTour = new OptionalTour();
					optionalTour.setTourId(rs.getString("TOUR_ID"));
					optionalTour.setTourName(rs.getString("TOUR_NAME"));
					optionalTour.setTourPrice(rs.getString("TOUR_PRICE"));
					optionalTour.setTourContent(rs.getString("TOUR_CONTENT"));

				}
			}
		}
		return optionalTour;
	}

}