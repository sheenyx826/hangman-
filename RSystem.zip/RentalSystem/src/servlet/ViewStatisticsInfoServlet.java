package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.StatisticsInfo;
import constants.ConstURL;
import dao.StatisticsInfoDAO;
import ds.ConnectionManager;

/**
 * 統計情報一覧表示サーブレット
 */
@WebServlet("/ViewStatisticsInfoServlet")
public class ViewStatisticsInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try (Connection con = ConnectionManager.getConnection()) {
			StatisticsInfoDAO dao = new StatisticsInfoDAO(con);
			List<StatisticsInfo> statisticsInfoList = dao.selectAll();
			request.setAttribute("statisticsInfoList", statisticsInfoList);
		} catch (SQLException | NamingException e) {
			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
		}
		String url = ConstURL.ViewStatisticsInfo_PATH;
		request.getRequestDispatcher(url).forward(request, response);
	}

}
