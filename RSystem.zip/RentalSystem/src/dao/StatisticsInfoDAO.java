package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.StatisticsInfo;

/**
 * テンプレートテーブルを管理するクラス。
 *
 * @author yokin
 */
public class StatisticsInfoDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 * 
	 * @param コネクション
	 */
	public StatisticsInfoDAO(Connection con) {
		this.con = con;
	}

	/**
	 * 統計情報全件検索
	 * 
	 * @return
	 * @throws SQLException
	 */
	public List<StatisticsInfo> selectAll() throws SQLException {
		String sql = "SELECT STATISTIC_DATE,EMPLOYEE_COUNT,EMPLOYEE_AVERAGE_AGE FROM STATISTICS_INFO ORDER BY STATISTIC_DATE DESC";
		List<StatisticsInfo> list = new ArrayList<StatisticsInfo>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				StatisticsInfo statisticsInfo = new StatisticsInfo();
				statisticsInfo.setUpdateTime(rs.getTimestamp("STATISTIC_DATE"));
				statisticsInfo.setAmount(rs.getInt("EMPLOYEE_COUNT"));
				statisticsInfo.setAveAge(rs.getInt("EMPLOYEE_AVERAGE_AGE"));
				list.add(statisticsInfo);
			}
		}
		return list;
	}

	/**
	 * 統計情報登録
	 * 
	 * @return
	 * @throws SQLException
	 */
	public int insert() throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO STATISTICS_INFO(STATISTIC_DATE, EMPLOYEE_COUNT, EMPLOYEE_AVERAGE_AGE) SELECT SYSDATE STATISTIC_DATE,COUNT(*) EMPLOYEE_COUNT, AVG(EMPLOYEE_AGE) EMPLOYEE_AVERAGE_AGE FROM EMPLOYEES,DUAL";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			cnt = ps.executeUpdate();
		}
		return cnt;
	}

}