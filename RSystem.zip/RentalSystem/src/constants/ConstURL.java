package constants;

/**
 * @author URLを保持するクラス
 *
 */
public class ConstURL {
	public static final String InsertInput_PATH = "\\WEB-INF\\pages\\InsertInputPage.jsp";
	public static final String InsertDone_PATH = "\\WEB-INF\\pages\\InsertDonePage.jsp";
	public static final String UpdateDone_PATH = "\\WEB-INF\\pages\\UpdateDonePage.jsp";
	public static final String UpdateInput_PATH = "\\WEB-INF\\pages\\UpdateInputPage.jsp";
	public static final String ViewStatisticsInfo_PATH = "\\WEB-INF\\pages\\viewStatisticsInfoPage.jsp";
	public static final String ViewEmployees_PATH = "\\WEB-INF\\pages\\viewEmployeesPage.jsp";

}